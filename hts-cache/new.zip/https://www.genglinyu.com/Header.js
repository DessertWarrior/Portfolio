<!doctype html>
<html xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml" lang="en-US"  >
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- This is Squarespace. --><!-- shallot-mauve-hhrw -->
<base href="">
<meta charset="utf-8" />
<title>Genglin Yu</title>
<meta http-equiv="Accept-CH" content="Sec-CH-UA-Platform-Version, Sec-CH-UA-Model" /><link rel="icon" type="image/x-icon" href="https://assets.squarespace.com/universal/default-favicon.ico"/>
<meta property="og:site_name" content="Genglin Yu"/>
<meta property="og:title" content="Genglin Yu"/>
<meta property="og:type" content="website"/>
<meta property="og:image" content="http://images.squarespace-cdn.com/content/v1/6ad6ea4859e481727b113c39/af7d0cb8-e46e-462e-b1eb-871ba18b206f/logotype.png?format=1500w"/>
<meta itemprop="name" content="Genglin Yu"/>
<meta itemprop="thumbnailUrl" content="http://images.squarespace-cdn.com/content/v1/6ad6ea4859e481727b113c39/af7d0cb8-e46e-462e-b1eb-871ba18b206f/logotype.png?format=1500w"/>
<link rel="image_src" href="http://images.squarespace-cdn.com/content/v1/6ad6ea4859e481727b113c39/af7d0cb8-e46e-462e-b1eb-871ba18b206f/logotype.png?format=1500w" />
<meta itemprop="image" content="http://images.squarespace-cdn.com/content/v1/6ad6ea4859e481727b113c39/af7d0cb8-e46e-462e-b1eb-871ba18b206f/logotype.png?format=1500w"/>
<meta name="twitter:title" content="Genglin Yu"/>
<meta name="twitter:image" content="http://images.squarespace-cdn.com/content/v1/6ad6ea4859e481727b113c39/af7d0cb8-e46e-462e-b1eb-871ba18b206f/logotype.png?format=1500w"/>
<meta name="twitter:card" content="summary"/>
<meta name="description" content="" />
<link rel="preconnect" href="https://images.squarespace-cdn.com">
<link rel="preconnect" href="https://file.squarespace-cdn.com" crossorigin>
<style data-sqsp-font-ids="6a3137d3494e3c6626e63abc,6a3139e4691a2d058d1a1be6">
/* latin */
@font-face {
  font-family: 'Manrope';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/01320e30-4bf6-4eca-8ac6-768b9927c6a9/latin.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Manrope';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/c240fcf3-5690-4097-9cd6-2295e481d559/vietnamese.woff2') format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Manrope';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/09a2c607-fe28-425b-aa2d-9a7b64daff39/cyrillic-ext.woff2') format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* greek */
@font-face {
  font-family: 'Manrope';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/58939b86-e6d5-481e-a361-5e62b8be01c1/greek.woff2') format('woff2');
  unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
}
/* cyrillic */
@font-face {
  font-family: 'Manrope';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/494faa42-b773-4ba6-9b8d-9b37842713ca/cyrillic.woff2') format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* latin-ext */
@font-face {
  font-family: 'Manrope';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/0d5f4812-4d7d-4576-9468-aaee1fd4be34/latin-ext.woff2') format('woff2');
  unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin-ext */
@font-face {
  font-family: 'Poppins';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/e5441b3f-475c-4dd0-815e-d1493a6eef24/latin-ext.woff2') format('woff2');
  unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* devanagari */
@font-face {
  font-family: 'Poppins';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/e364ec28-4783-442b-b46f-59d33a99dd2c/devanagari.woff2') format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839, U+A8E0-A8FF, U+11B00-11B09;
}
/* latin */
@font-face {
  font-family: 'Poppins';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/67451c8f-d5ad-40d0-a48b-1e842ade5679/latin.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/d03c0883-8248-47bf-9fa3-437f8474b0b7/latin-ext.woff2') format('woff2');
  unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/da0c3c0d-458f-46e2-9c64-bac004d4e8c1/latin.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* devanagari */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/7050a57e-968a-4317-a487-11e4374878d9/devanagari.woff2') format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839, U+A8E0-A8FF, U+11B00-11B09;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Manrope';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/1ea04a7d-9d50-40eb-8889-89e7a997c48b/cyrillic-ext.woff2') format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C8A, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* greek */
@font-face {
  font-family: 'Manrope';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/0f0515d8-7fda-4fb7-9750-d5d8ee499e38/greek.woff2') format('woff2');
  unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
}
/* cyrillic */
@font-face {
  font-family: 'Manrope';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/66dde975-4bb9-47c1-8f6b-2220cf3bb06d/cyrillic.woff2') format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* latin */
@font-face {
  font-family: 'Manrope';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/99dd7d2a-e2aa-4dc5-a25f-1bab59dfff1a/latin.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Manrope';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/33d80dff-9844-4e8d-a1fc-63c9a3323a8c/latin-ext.woff2') format('woff2');
  unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* vietnamese */
@font-face {
  font-family: 'Manrope';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/51449cd1-6c79-4f03-94fc-5feecddf74ee/vietnamese.woff2') format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Poppins';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/28866714-3a03-4fde-b82e-bcffd944752e/latin-ext.woff2') format('woff2');
  unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Poppins';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/ab6b1da4-72e3-4abf-a176-e7a8a24b53d1/latin.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* devanagari */
@font-face {
  font-family: 'Poppins';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/7d30df3b-ed0a-4cdd-824a-b3c7e5e49f0d/devanagari.woff2') format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839, U+A8E0-A8FF, U+11B00-11B09;
}
/* latin */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/95402d3d-cf4f-4ff3-b652-fa1bddbe79de/latin.woff2') format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* devanagari */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/31f2dfaf-de1e-40ab-ac18-8641e6ac98d0/devanagari.woff2') format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF9, U+200C-200D, U+20A8, U+20B9, U+20F0, U+25CC, U+A830-A839, U+A8E0-A8FF, U+11B00-11B09;
}
/* latin-ext */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url('https://file.squarespace-cdn.com/content/v2/namespaces/fonts/libraries/sqsp/assets/ab5cf469-e78c-4791-92a2-a2e360e24c1d/latin-ext.woff2') format('woff2');
  unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
</style><script type="text/javascript" crossorigin="anonymous" defer="true" src="//assets.squarespace.com/@sqs/polyfiller/1.7.7/modern.js"></script>
<script data-name="static-context">Static = window.Static || {}; Static.SQUARESPACE_CONTEXT = {"betaFeatureFlags":["marketing_automations","in-product-messaging-banners-oct-5","nested_categories","campaigns_discount_section_in_blasts","campaigns_merch_state","scripts_defer","output_template_css_assets","supports_versioned_template_assets","marketing_landing_page","campaigns_table_v2","campaigns_import_discounts","contacts_and_campaigns_redesign","member_areas_feature","cdk_website_components_video_lazy_loading_enabled","new_stacked_index","campaigns_new_image_layout_picker","sms-campaigns","website_styles_ui_enabled","enable_form_submission_trigger","override_block_styles","campaigns_thumbnail_layout","cdk_website_components_video_container_styles_enabled","campaigns_discount_section_in_automations","commerce_product_payment_plan_editing","i18n_beta_website_locales"],"facebookAppId":"314192535267336","facebookApiVersion":"v6.0","rollups":{"squarespace-announcement-bar":{"js":"//assets.squarespace.com/universal/scripts-compressed/announcement-bar-898b8c17afd4afbb-min.en-US.js"},"squarespace-audio-player":{"css":"//assets.squarespace.com/universal/styles-compressed/audio-player-b05f5197a871c566-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/audio-player-73ddba22b0661fd1-min.en-US.js"},"squarespace-blog-collection-list":{"css":"//assets.squarespace.com/universal/styles-compressed/blog-collection-list-b4046463b72f34e2-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/blog-collection-list-8689c953a903f5de-min.en-US.js"},"squarespace-calendar-block-renderer":{"css":"//assets.squarespace.com/universal/styles-compressed/calendar-block-renderer-c3fef2a497c8e56b-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/calendar-block-renderer-2fb818abddf23df3-min.en-US.js"},"squarespace-chartjs-helpers":{"css":"//assets.squarespace.com/universal/styles-compressed/chartjs-helpers-96b256171ee039c1-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/chartjs-helpers-a779e7b7ff94d821-min.en-US.js"},"squarespace-comments":{"css":"//assets.squarespace.com/universal/styles-compressed/comments-99b7af1d92eba1a5-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/comments-b1b7d3049eb4f8d6-min.en-US.js"},"squarespace-custom-css-popup":{"css":"//assets.squarespace.com/universal/styles-compressed/custom-css-popup-29518faed5760b2b-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/custom-css-popup-1d14e90d6750bb77-min.en-US.js"},"squarespace-dialog":{"css":"//assets.squarespace.com/universal/styles-compressed/dialog-86aacd645d83874c-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/dialog-b31c1c55e0249791-min.en-US.js"},"squarespace-events-collection":{"css":"//assets.squarespace.com/universal/styles-compressed/events-collection-c3fef2a497c8e56b-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/events-collection-00907994c917410f-min.en-US.js"},"squarespace-form-rendering-utils":{"js":"//assets.squarespace.com/universal/scripts-compressed/form-rendering-utils-6843762aaa3ddb9f-min.en-US.js"},"squarespace-forms":{"css":"//assets.squarespace.com/universal/styles-compressed/forms-0afd3c6ac30bbab1-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/forms-7971d402b5a662e8-min.en-US.js"},"squarespace-gallery-collection-list":{"css":"//assets.squarespace.com/universal/styles-compressed/gallery-collection-list-b4046463b72f34e2-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/gallery-collection-list-369b0edd6651fda7-min.en-US.js"},"squarespace-image-zoom":{"css":"//assets.squarespace.com/universal/styles-compressed/image-zoom-b4046463b72f34e2-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/image-zoom-bdebeb9b15addadb-min.en-US.js"},"squarespace-pinterest":{"css":"//assets.squarespace.com/universal/styles-compressed/pinterest-b4046463b72f34e2-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/pinterest-ad9e808acf9928e5-min.en-US.js"},"squarespace-popup-overlay":{"css":"//assets.squarespace.com/universal/styles-compressed/popup-overlay-b742b752f5880972-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/popup-overlay-c73119c1ab97b69b-min.en-US.js"},"squarespace-product-quick-view":{"css":"//assets.squarespace.com/universal/styles-compressed/product-quick-view-0afd3c6ac30bbab1-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/product-quick-view-40df551ac70b8e40-min.en-US.js"},"squarespace-products-collection-item-v2":{"css":"//assets.squarespace.com/universal/styles-compressed/products-collection-item-v2-b4046463b72f34e2-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/products-collection-item-v2-52c023b153bead6f-min.en-US.js"},"squarespace-products-collection-list-v2":{"css":"//assets.squarespace.com/universal/styles-compressed/products-collection-list-v2-b4046463b72f34e2-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/products-collection-list-v2-427e2a7b50430844-min.en-US.js"},"squarespace-search-page":{"css":"//assets.squarespace.com/universal/styles-compressed/search-page-90a67fc09b9b32c6-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/search-page-e820483d5402ce90-min.en-US.js"},"squarespace-search-preview":{"js":"//assets.squarespace.com/universal/scripts-compressed/search-preview-ad9cdf3a1656a47e-min.en-US.js"},"squarespace-simple-liking":{"css":"//assets.squarespace.com/universal/styles-compressed/simple-liking-701bf8bbc05ec6aa-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/simple-liking-a4003186f37d1d8b-min.en-US.js"},"squarespace-social-buttons":{"css":"//assets.squarespace.com/universal/styles-compressed/social-buttons-95032e5fa98e47a5-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/social-buttons-9d4887ee6ac038a3-min.en-US.js"},"squarespace-tourdates":{"css":"//assets.squarespace.com/universal/styles-compressed/tourdates-b4046463b72f34e2-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/tourdates-06ca1b33f45f61b8-min.en-US.js"},"squarespace-website-overlays-manager":{"css":"//assets.squarespace.com/universal/styles-compressed/website-overlays-manager-07ea5a4e004e6710-min.en-US.css","js":"//assets.squarespace.com/universal/scripts-compressed/website-overlays-manager-d33283eabcedc863-min.en-US.js"}},"pageType":100,"website":{"id":"6ad6ea4859e481727b113c39","captchaSettings":{"enabledForDonations":false},"cloneable":false,"contentModifiedOn":1792479339878,"formattingLocale":"en-US","fullSiteTitle":"Genglin Yu","identifier":"shallot-mauve-hhrw","imageMetadataProcessingEnabled":false,"isHstsEnabled":true,"language":"en-US","logoImageId":"6ad6fc698dce79760ce8bc8b","primaryDomain":"www.genglinyu.com","screenshotId":"e1f9d27a84a90d9e37f0272b901ca846a615b1f08771e84d5b3e0f45cf43f303","shareButtonOptions":{"1":true,"4":true,"7":true,"3":true,"8":true,"2":true,"6":true},"showOwnerLogin":false,"siteDescription":"","siteStatus":{},"siteTitle":"Genglin Yu","sslSetting":3,"timeZone":"America/Los_Angeles","translationLocale":"en-US","typekitId":"","websiteType":4,"statsMigrated":false,"authenticUrl":"https://www.genglinyu.com","baseUrl":"https://www.genglinyu.com","internalUrl":"https://shallot-mauve-hhrw.squarespace.com","logoImageUrl":"//images.squarespace-cdn.com/content/v1/6ad6ea4859e481727b113c39/af7d0cb8-e46e-462e-b1eb-871ba18b206f/logotype.png","machineTimeZoneOffset":-25200000,"socialAccounts":[{"serviceId":64,"screenname":"Instagram","addedOn":1792479364578,"profileUrl":"https://www.instagram.com/yu.genglin/","iconEnabled":true,"serviceName":"instagram-unauth"},{"serviceId":65,"screenname":"LinkedIn","addedOn":1792479364574,"profileUrl":"http://twitter.com/squarespacehttps://www.linkedin.com/in/genglin-yu/?isSelfProfile=true","iconEnabled":true,"serviceName":"linkedin-unauth"},{"serviceId":60,"screenname":"Facebook","addedOn":1792479364575,"profileUrl":"https://www.facebook.com/profile.php?id=100009310393967","iconEnabled":true,"serviceName":"facebook-unauth"}],"timeZoneAbbr":"PDT","timeZoneOffset":-25200000},"websiteSettings":{"id":"6ad6ea4959e481727b113c56","websiteId":"6ad6ea4859e481727b113c39","subjects":[],"country":"US","state":"CA","simpleLikingEnabled":true,"popupOverlaySettings":{"style":1,"enabledPages":[]},"commentLikesAllowed":true,"commentAnonAllowed":true,"commentThreaded":true,"commentApprovalRequired":false,"commentAvatarsOn":true,"commentSortType":2,"commentFlagThreshold":0,"commentFlagsAllowed":true,"commentEnableByDefault":true,"commentDisableAfterDaysDefault":0,"disqusShortname":"","commentsEnabled":false,"storeSettings":{"returnPolicy":null,"termsOfService":null,"privacyPolicy":null,"expressCheckout":false,"continueShoppingLinkUrl":"/","useLightCart":false,"showNoteField":false,"shippingCountryDefaultValue":"US","billToShippingDefaultValue":false,"showShippingPhoneNumber":true,"isShippingPhoneRequired":false,"showBillingPhoneNumber":true,"isBillingPhoneRequired":false,"currenciesSupported":["USD","CAD","GBP","AUD","EUR","CHF","NOK","SEK","DKK","NZD","SGD","MXN","HKD","CZK","ILS","MYR","RUB","PHP","PLN","THB","BRL","ARS","COP","IDR","INR","JPY","ZAR","KRW"],"defaultCurrency":"USD","selectedCurrency":"USD","multicurrencyEnabled":true,"measurementStandard":1,"showCustomCheckoutForm":false,"checkoutPageMarketingOptInEnabled":true,"enableMailingListOptInByDefault":false,"sameAsRetailLocation":false,"merchandisingSettings":{"scarcityEnabledOnProductItems":false,"scarcityEnabledOnProductBlocks":false,"scarcityMessageType":"DEFAULT_SCARCITY_MESSAGE","scarcityThreshold":10,"multipleQuantityAllowedForServices":true,"restockNotificationsEnabled":false,"restockNotificationsMailingListSignUpEnabled":false,"relatedProductsEnabled":false,"relatedProductsOrdering":"random","soldOutVariantsDropdownDisabled":false,"productComposerOptedIn":false,"productComposerABTestOptedOut":false,"productReviewsEnabled":false},"minimumOrderSubtotalEnabled":false,"minimumOrderSubtotal":{"currency":"USD","value":"0.00"},"addToCartConfirmationType":2,"isLive":false,"multipleQuantityAllowedForServices":true},"useEscapeKeyToLogin":false,"ssBadgeType":1,"ssBadgePosition":4,"ssBadgeVisibility":1,"ssBadgeDevices":1,"pinterestOverlayOptions":{"mode":"disabled"},"userAccountsSettings":{"loginAllowed":true,"signupAllowed":true}},"cookieSettings":{"isCookieBannerEnabled":false,"isRestrictiveCookiePolicyEnabled":false,"cookieBannerText":"","cookieBannerTheme":"","cookieBannerVariant":"","cookieBannerPosition":"","cookieBannerCtaVariant":"","cookieBannerCtaText":"","cookieBannerAcceptType":"OPT_IN","cookieBannerOptOutCtaText":"","cookieBannerHasOptOut":false,"cookieBannerHasManageCookies":true,"cookieBannerManageCookiesLabel":"","cookieBannerSavedPreferencesText":"","cookieBannerSavedPreferencesLayout":"PILL"},"websiteCloneable":false,"subscribed":false,"appDomain":"squarespace.com","templateTweakable":true,"tweakJSON":{"form-use-theme-colors":"true","header-logo-height":"213px","header-mobile-logo-max-height":"96px","header-vert-padding":"0.1vw","header-width":"Inset","maxPageWidth":"2000px","mobile-header-vert-padding":"6vw","pagePadding":"2vw","tweak-blog-alternating-side-by-side-image-aspect-ratio":"1:1 Square","tweak-blog-alternating-side-by-side-image-spacing":"6%","tweak-blog-alternating-side-by-side-meta-spacing":"20px","tweak-blog-alternating-side-by-side-primary-meta":"Categories","tweak-blog-alternating-side-by-side-read-more-spacing":"20px","tweak-blog-alternating-side-by-side-secondary-meta":"Date","tweak-blog-basic-grid-columns":"2","tweak-blog-basic-grid-image-aspect-ratio":"3:2 Standard","tweak-blog-basic-grid-image-spacing":"20px","tweak-blog-basic-grid-meta-spacing":"10px","tweak-blog-basic-grid-primary-meta":"Date","tweak-blog-basic-grid-read-more-spacing":"20px","tweak-blog-basic-grid-secondary-meta":"Categories","tweak-blog-item-custom-width":"75","tweak-blog-item-show-author-profile":"false","tweak-blog-item-width":"Medium","tweak-blog-masonry-columns":"2","tweak-blog-masonry-horizontal-spacing":"30px","tweak-blog-masonry-image-spacing":"20px","tweak-blog-masonry-meta-spacing":"20px","tweak-blog-masonry-primary-meta":"Categories","tweak-blog-masonry-read-more-spacing":"20px","tweak-blog-masonry-secondary-meta":"Date","tweak-blog-masonry-vertical-spacing":"30px","tweak-blog-side-by-side-image-aspect-ratio":"1:1 Square","tweak-blog-side-by-side-image-spacing":"6%","tweak-blog-side-by-side-meta-spacing":"20px","tweak-blog-side-by-side-primary-meta":"Categories","tweak-blog-side-by-side-read-more-spacing":"20px","tweak-blog-side-by-side-secondary-meta":"Date","tweak-blog-single-column-image-spacing":"50px","tweak-blog-single-column-meta-spacing":"0px","tweak-blog-single-column-primary-meta":"Date","tweak-blog-single-column-read-more-spacing":"0px","tweak-blog-single-column-secondary-meta":"Categories","tweak-events-stacked-show-thumbnails":"true","tweak-events-stacked-thumbnail-size":"3:2 Standard","tweak-fixed-header":"false","tweak-fixed-header-style":"Basic","tweak-global-animations-animation-curve":"ease","tweak-global-animations-animation-delay":"0.1s","tweak-global-animations-animation-duration":"0.1s","tweak-global-animations-animation-style":"fade","tweak-global-animations-animation-type":"none","tweak-global-animations-complexity-level":"detailed","tweak-global-animations-enabled":"false","tweak-portfolio-grid-basic-custom-height":"50","tweak-portfolio-grid-overlay-custom-height":"50","tweak-portfolio-hover-follow-acceleration":"10%","tweak-portfolio-hover-follow-animation-duration":"Fast","tweak-portfolio-hover-follow-animation-type":"Fade","tweak-portfolio-hover-follow-delimiter":"Bullet","tweak-portfolio-hover-follow-front":"false","tweak-portfolio-hover-follow-layout":"Inline","tweak-portfolio-hover-follow-size":"50","tweak-portfolio-hover-follow-text-spacing-x":"1.5","tweak-portfolio-hover-follow-text-spacing-y":"1.5","tweak-portfolio-hover-static-animation-duration":"Fast","tweak-portfolio-hover-static-animation-type":"Fade","tweak-portfolio-hover-static-delimiter":"Hyphen","tweak-portfolio-hover-static-front":"true","tweak-portfolio-hover-static-layout":"Inline","tweak-portfolio-hover-static-size":"50","tweak-portfolio-hover-static-text-spacing-x":"1.5","tweak-portfolio-hover-static-text-spacing-y":"1.5","tweak-portfolio-index-background-animation-duration":"Medium","tweak-portfolio-index-background-animation-type":"Fade","tweak-portfolio-index-background-custom-height":"50","tweak-portfolio-index-background-delimiter":"None","tweak-portfolio-index-background-height":"Large","tweak-portfolio-index-background-horizontal-alignment":"Center","tweak-portfolio-index-background-link-format":"Stacked","tweak-portfolio-index-background-persist":"false","tweak-portfolio-index-background-vertical-alignment":"Middle","tweak-portfolio-index-background-width":"Full","tweak-transparent-header":"false"},"websiteStyles":{"spacing":{"maxPageWidth":"2000px","pagePadding":"2vw"},"animations":{"tweak-global-animations-enabled":"false","tweak-global-animations-animation-type":"none","tweak-global-animations-animation-curve":"ease","tweak-global-animations-animation-duration":"0.1s","tweak-global-animations-animation-delay":"0.1s"}},"templateId":"5c5a519771c10ba3470d8101","templateVersion":"7.1","pageFeatures":[1,4],"gmRenderKey":"QUl6YVN5Q0JUUk9xNkx1dkZfSUUxcjQ2LVQ0QWVUU1YtMGQ3bXk4","templateScriptsRootUrl":"https://static1.squarespace.com/static/vta/5c5a519771c10ba3470d8101/scripts/","impersonatedSession":false,"tzData":{"zones":[[-480,"US","P%sT",null]],"rules":{"US":[[1967,2006,null,"Oct","lastSun","2:00","0","S"],[1987,2006,null,"Apr","Sun>=1","2:00","1:00","D"],[2007,"max",null,"Mar","Sun>=8","2:00","1:00","D"],[2007,"max",null,"Nov","Sun>=1","2:00","0","S"]]}},"showAnnouncementBar":false,"recaptchaEnterpriseContext":{"recaptchaEnterpriseSiteKey":"6LdDFQwjAAAAAPigEvvPgEVbb7QBm-TkVJdDTlAv"},"i18nContext":{"timeZoneData":{"id":"America/Los_Angeles","name":"Pacific Time"}},"env":"PRODUCTION","visitorFormContext":{"formFieldFormats":{"initialAddressFormat":{"id":0,"type":"ADDRESS","country":"US","labelLocale":"en","fields":[{"type":"FIELD","label":"Address Line 1","identifier":"Line1","length":0,"required":true,"metadata":{"autocomplete":"address-line1"}},{"type":"SEPARATOR","label":"\n","identifier":"Newline","length":0,"required":false,"metadata":{}},{"type":"FIELD","label":"Address Line 2","identifier":"Line2","length":0,"required":false,"metadata":{"autocomplete":"address-line2"}},{"type":"SEPARATOR","label":"\n","identifier":"Newline","length":0,"required":false,"metadata":{}},{"type":"FIELD","label":"City","identifier":"City","length":0,"required":true,"metadata":{"autocomplete":"address-level2"}},{"type":"SEPARATOR","label":",","identifier":"Comma","length":0,"required":false,"metadata":{}},{"type":"SEPARATOR","label":" ","identifier":"Space","length":0,"required":false,"metadata":{}},{"type":"FIELD","label":"State","identifier":"State","length":0,"required":true,"metadata":{"autocomplete":"address-level1"}},{"type":"SEPARATOR","label":" ","identifier":"Space","length":0,"required":false,"metadata":{}},{"type":"FIELD","label":"ZIP Code","identifier":"Zip","length":0,"required":true,"metadata":{"autocomplete":"postal-code"}}]},"initialNameOrder":"GIVEN_FIRST","initialPhoneFormat":{"id":0,"type":"PHONE_NUMBER","country":"US","labelLocale":"en-US","fields":[{"type":"SEPARATOR","label":"(","identifier":"LeftParen","length":0,"required":false,"metadata":{}},{"type":"FIELD","label":"1","identifier":"1","length":3,"required":false,"metadata":{}},{"type":"SEPARATOR","label":")","identifier":"RightParen","length":0,"required":false,"metadata":{}},{"type":"SEPARATOR","label":" ","identifier":"Space","length":0,"required":false,"metadata":{}},{"type":"FIELD","label":"2","identifier":"2","length":3,"required":false,"metadata":{}},{"type":"SEPARATOR","label":"-","identifier":"Dash","length":0,"required":false,"metadata":{}},{"type":"FIELD","label":"3","identifier":"3","length":14,"required":false,"metadata":{}}]},"countries":[{"name":"Afghanistan","code":"AF","phoneCode":"+93"},{"name":"\u00C5land Islands","code":"AX","phoneCode":"+358"},{"name":"Albania","code":"AL","phoneCode":"+355"},{"name":"Algeria","code":"DZ","phoneCode":"+213"},{"name":"American Samoa","code":"AS","phoneCode":"+1"},{"name":"Andorra","code":"AD","phoneCode":"+376"},{"name":"Angola","code":"AO","phoneCode":"+244"},{"name":"Anguilla","code":"AI","phoneCode":"+1"},{"name":"Antigua & Barbuda","code":"AG","phoneCode":"+1"},{"name":"Argentina","code":"AR","phoneCode":"+54"},{"name":"Armenia","code":"AM","phoneCode":"+374"},{"name":"Aruba","code":"AW","phoneCode":"+297"},{"name":"Ascension Island","code":"AC","phoneCode":"+247"},{"name":"Australia","code":"AU","phoneCode":"+61"},{"name":"Austria","code":"AT","phoneCode":"+43"},{"name":"Azerbaijan","code":"AZ","phoneCode":"+994"},{"name":"Bahamas","code":"BS","phoneCode":"+1"},{"name":"Bahrain","code":"BH","phoneCode":"+973"},{"name":"Bangladesh","code":"BD","phoneCode":"+880"},{"name":"Barbados","code":"BB","phoneCode":"+1"},{"name":"Belarus","code":"BY","phoneCode":"+375"},{"name":"Belgium","code":"BE","phoneCode":"+32"},{"name":"Belize","code":"BZ","phoneCode":"+501"},{"name":"Benin","code":"BJ","phoneCode":"+229"},{"name":"Bermuda","code":"BM","phoneCode":"+1"},{"name":"Bhutan","code":"BT","phoneCode":"+975"},{"name":"Bolivia","code":"BO","phoneCode":"+591"},{"name":"Bosnia & Herzegovina","code":"BA","phoneCode":"+387"},{"name":"Botswana","code":"BW","phoneCode":"+267"},{"name":"Brazil","code":"BR","phoneCode":"+55"},{"name":"British Indian Ocean Territory","code":"IO","phoneCode":"+246"},{"name":"British Virgin Islands","code":"VG","phoneCode":"+1"},{"name":"Brunei","code":"BN","phoneCode":"+673"},{"name":"Bulgaria","code":"BG","phoneCode":"+359"},{"name":"Burkina Faso","code":"BF","phoneCode":"+226"},{"name":"Burundi","code":"BI","phoneCode":"+257"},{"name":"Cambodia","code":"KH","phoneCode":"+855"},{"name":"Cameroon","code":"CM","phoneCode":"+237"},{"name":"Canada","code":"CA","phoneCode":"+1"},{"name":"Cape Verde","code":"CV","phoneCode":"+238"},{"name":"Caribbean Netherlands","code":"BQ","phoneCode":"+599"},{"name":"Cayman Islands","code":"KY","phoneCode":"+1"},{"name":"Central African Republic","code":"CF","phoneCode":"+236"},{"name":"Chad","code":"TD","phoneCode":"+235"},{"name":"Chile","code":"CL","phoneCode":"+56"},{"name":"China","code":"CN","phoneCode":"+86"},{"name":"Christmas Island","code":"CX","phoneCode":"+61"},{"name":"Cocos (Keeling) Islands","code":"CC","phoneCode":"+61"},{"name":"Colombia","code":"CO","phoneCode":"+57"},{"name":"Comoros","code":"KM","phoneCode":"+269"},{"name":"Congo - Brazzaville","code":"CG","phoneCode":"+242"},{"name":"Congo - Kinshasa","code":"CD","phoneCode":"+243"},{"name":"Cook Islands","code":"CK","phoneCode":"+682"},{"name":"Costa Rica","code":"CR","phoneCode":"+506"},{"name":"C\u00F4te d\u2019Ivoire","code":"CI","phoneCode":"+225"},{"name":"Croatia","code":"HR","phoneCode":"+385"},{"name":"Cuba","code":"CU","phoneCode":"+53"},{"name":"Cura\u00E7ao","code":"CW","phoneCode":"+599"},{"name":"Cyprus","code":"CY","phoneCode":"+357"},{"name":"Czechia","code":"CZ","phoneCode":"+420"},{"name":"Denmark","code":"DK","phoneCode":"+45"},{"name":"Djibouti","code":"DJ","phoneCode":"+253"},{"name":"Dominica","code":"DM","phoneCode":"+1"},{"name":"Dominican Republic","code":"DO","phoneCode":"+1"},{"name":"Ecuador","code":"EC","phoneCode":"+593"},{"name":"Egypt","code":"EG","phoneCode":"+20"},{"name":"El Salvador","code":"SV","phoneCode":"+503"},{"name":"Equatorial Guinea","code":"GQ","phoneCode":"+240"},{"name":"Eritrea","code":"ER","phoneCode":"+291"},{"name":"Estonia","code":"EE","phoneCode":"+372"},{"name":"Eswatini","code":"SZ","phoneCode":"+268"},{"name":"Ethiopia","code":"ET","phoneCode":"+251"},{"name":"Falkland Islands","code":"FK","phoneCode":"+500"},{"name":"Faroe Islands","code":"FO","phoneCode":"+298"},{"name":"Fiji","code":"FJ","phoneCode":"+679"},{"name":"Finland","code":"FI","phoneCode":"+358"},{"name":"France","code":"FR","phoneCode":"+33"},{"name":"French Guiana","code":"GF","phoneCode":"+594"},{"name":"French Polynesia","code":"PF","phoneCode":"+689"},{"name":"Gabon","code":"GA","phoneCode":"+241"},{"name":"Gambia","code":"GM","phoneCode":"+220"},{"name":"Georgia","code":"GE","phoneCode":"+995"},{"name":"Germany","code":"DE","phoneCode":"+49"},{"name":"Ghana","code":"GH","phoneCode":"+233"},{"name":"Gibraltar","code":"GI","phoneCode":"+350"},{"name":"Greece","code":"GR","phoneCode":"+30"},{"name":"Greenland","code":"GL","phoneCode":"+299"},{"name":"Grenada","code":"GD","phoneCode":"+1"},{"name":"Guadeloupe","code":"GP","phoneCode":"+590"},{"name":"Guam","code":"GU","phoneCode":"+1"},{"name":"Guatemala","code":"GT","phoneCode":"+502"},{"name":"Guernsey","code":"GG","phoneCode":"+44"},{"name":"Guinea","code":"GN","phoneCode":"+224"},{"name":"Guinea-Bissau","code":"GW","phoneCode":"+245"},{"name":"Guyana","code":"GY","phoneCode":"+592"},{"name":"Haiti","code":"HT","phoneCode":"+509"},{"name":"Honduras","code":"HN","phoneCode":"+504"},{"name":"Hong Kong SAR China","code":"HK","phoneCode":"+852"},{"name":"Hungary","code":"HU","phoneCode":"+36"},{"name":"Iceland","code":"IS","phoneCode":"+354"},{"name":"India","code":"IN","phoneCode":"+91"},{"name":"Indonesia","code":"ID","phoneCode":"+62"},{"name":"Iran","code":"IR","phoneCode":"+98"},{"name":"Iraq","code":"IQ","phoneCode":"+964"},{"name":"Ireland","code":"IE","phoneCode":"+353"},{"name":"Isle of Man","code":"IM","phoneCode":"+44"},{"name":"Israel","code":"IL","phoneCode":"+972"},{"name":"Italy","code":"IT","phoneCode":"+39"},{"name":"Jamaica","code":"JM","phoneCode":"+1"},{"name":"Japan","code":"JP","phoneCode":"+81"},{"name":"Jersey","code":"JE","phoneCode":"+44"},{"name":"Jordan","code":"JO","phoneCode":"+962"},{"name":"Kazakhstan","code":"KZ","phoneCode":"+7"},{"name":"Kenya","code":"KE","phoneCode":"+254"},{"name":"Kiribati","code":"KI","phoneCode":"+686"},{"name":"Kosovo","code":"XK","phoneCode":"+383"},{"name":"Kuwait","code":"KW","phoneCode":"+965"},{"name":"Kyrgyzstan","code":"KG","phoneCode":"+996"},{"name":"Laos","code":"LA","phoneCode":"+856"},{"name":"Latvia","code":"LV","phoneCode":"+371"},{"name":"Lebanon","code":"LB","phoneCode":"+961"},{"name":"Lesotho","code":"LS","phoneCode":"+266"},{"name":"Liberia","code":"LR","phoneCode":"+231"},{"name":"Libya","code":"LY","phoneCode":"+218"},{"name":"Liechtenstein","code":"LI","phoneCode":"+423"},{"name":"Lithuania","code":"LT","phoneCode":"+370"},{"name":"Luxembourg","code":"LU","phoneCode":"+352"},{"name":"Macao SAR China","code":"MO","phoneCode":"+853"},{"name":"Madagascar","code":"MG","phoneCode":"+261"},{"name":"Malawi","code":"MW","phoneCode":"+265"},{"name":"Malaysia","code":"MY","phoneCode":"+60"},{"name":"Maldives","code":"MV","phoneCode":"+960"},{"name":"Mali","code":"ML","phoneCode":"+223"},{"name":"Malta","code":"MT","phoneCode":"+356"},{"name":"Marshall Islands","code":"MH","phoneCode":"+692"},{"name":"Martinique","code":"MQ","phoneCode":"+596"},{"name":"Mauritania","code":"MR","phoneCode":"+222"},{"name":"Mauritius","code":"MU","phoneCode":"+230"},{"name":"Mayotte","code":"YT","phoneCode":"+262"},{"name":"Mexico","code":"MX","phoneCode":"+52"},{"name":"Micronesia","code":"FM","phoneCode":"+691"},{"name":"Moldova","code":"MD","phoneCode":"+373"},{"name":"Monaco","code":"MC","phoneCode":"+377"},{"name":"Mongolia","code":"MN","phoneCode":"+976"},{"name":"Montenegro","code":"ME","phoneCode":"+382"},{"name":"Montserrat","code":"MS","phoneCode":"+1"},{"name":"Morocco","code":"MA","phoneCode":"+212"},{"name":"Mozambique","code":"MZ","phoneCode":"+258"},{"name":"Myanmar (Burma)","code":"MM","phoneCode":"+95"},{"name":"Namibia","code":"NA","phoneCode":"+264"},{"name":"Nauru","code":"NR","phoneCode":"+674"},{"name":"Nepal","code":"NP","phoneCode":"+977"},{"name":"Netherlands","code":"NL","phoneCode":"+31"},{"name":"New Caledonia","code":"NC","phoneCode":"+687"},{"name":"New Zealand","code":"NZ","phoneCode":"+64"},{"name":"Nicaragua","code":"NI","phoneCode":"+505"},{"name":"Niger","code":"NE","phoneCode":"+227"},{"name":"Nigeria","code":"NG","phoneCode":"+234"},{"name":"Niue","code":"NU","phoneCode":"+683"},{"name":"Norfolk Island","code":"NF","phoneCode":"+672"},{"name":"Northern Mariana Islands","code":"MP","phoneCode":"+1"},{"name":"North Korea","code":"KP","phoneCode":"+850"},{"name":"North Macedonia","code":"MK","phoneCode":"+389"},{"name":"Norway","code":"NO","phoneCode":"+47"},{"name":"Oman","code":"OM","phoneCode":"+968"},{"name":"Pakistan","code":"PK","phoneCode":"+92"},{"name":"Palau","code":"PW","phoneCode":"+680"},{"name":"Palestinian Territories","code":"PS","phoneCode":"+970"},{"name":"Panama","code":"PA","phoneCode":"+507"},{"name":"Papua New Guinea","code":"PG","phoneCode":"+675"},{"name":"Paraguay","code":"PY","phoneCode":"+595"},{"name":"Peru","code":"PE","phoneCode":"+51"},{"name":"Philippines","code":"PH","phoneCode":"+63"},{"name":"Poland","code":"PL","phoneCode":"+48"},{"name":"Portugal","code":"PT","phoneCode":"+351"},{"name":"Puerto Rico","code":"PR","phoneCode":"+1"},{"name":"Qatar","code":"QA","phoneCode":"+974"},{"name":"R\u00E9union","code":"RE","phoneCode":"+262"},{"name":"Romania","code":"RO","phoneCode":"+40"},{"name":"Russia","code":"RU","phoneCode":"+7"},{"name":"Rwanda","code":"RW","phoneCode":"+250"},{"name":"Samoa","code":"WS","phoneCode":"+685"},{"name":"San Marino","code":"SM","phoneCode":"+378"},{"name":"S\u00E3o Tom\u00E9 & Pr\u00EDncipe","code":"ST","phoneCode":"+239"},{"name":"Saudi Arabia","code":"SA","phoneCode":"+966"},{"name":"Senegal","code":"SN","phoneCode":"+221"},{"name":"Serbia","code":"RS","phoneCode":"+381"},{"name":"Seychelles","code":"SC","phoneCode":"+248"},{"name":"Sierra Leone","code":"SL","phoneCode":"+232"},{"name":"Singapore","code":"SG","phoneCode":"+65"},{"name":"Sint Maarten","code":"SX","phoneCode":"+1"},{"name":"Slovakia","code":"SK","phoneCode":"+421"},{"name":"Slovenia","code":"SI","phoneCode":"+386"},{"name":"Solomon Islands","code":"SB","phoneCode":"+677"},{"name":"Somalia","code":"SO","phoneCode":"+252"},{"name":"South Africa","code":"ZA","phoneCode":"+27"},{"name":"South Korea","code":"KR","phoneCode":"+82"},{"name":"South Sudan","code":"SS","phoneCode":"+211"},{"name":"Spain","code":"ES","phoneCode":"+34"},{"name":"Sri Lanka","code":"LK","phoneCode":"+94"},{"name":"St. Barth\u00E9lemy","code":"BL","phoneCode":"+590"},{"name":"St. Helena","code":"SH","phoneCode":"+290"},{"name":"St. Kitts & Nevis","code":"KN","phoneCode":"+1"},{"name":"St. Lucia","code":"LC","phoneCode":"+1"},{"name":"St. Martin","code":"MF","phoneCode":"+590"},{"name":"St. Pierre & Miquelon","code":"PM","phoneCode":"+508"},{"name":"St. Vincent & Grenadines","code":"VC","phoneCode":"+1"},{"name":"Sudan","code":"SD","phoneCode":"+249"},{"name":"Suriname","code":"SR","phoneCode":"+597"},{"name":"Svalbard & Jan Mayen","code":"SJ","phoneCode":"+47"},{"name":"Sweden","code":"SE","phoneCode":"+46"},{"name":"Switzerland","code":"CH","phoneCode":"+41"},{"name":"Syria","code":"SY","phoneCode":"+963"},{"name":"Taiwan","code":"TW","phoneCode":"+886"},{"name":"Tajikistan","code":"TJ","phoneCode":"+992"},{"name":"Tanzania","code":"TZ","phoneCode":"+255"},{"name":"Thailand","code":"TH","phoneCode":"+66"},{"name":"Timor-Leste","code":"TL","phoneCode":"+670"},{"name":"Togo","code":"TG","phoneCode":"+228"},{"name":"Tokelau","code":"TK","phoneCode":"+690"},{"name":"Tonga","code":"TO","phoneCode":"+676"},{"name":"Trinidad & Tobago","code":"TT","phoneCode":"+1"},{"name":"Tristan da Cunha","code":"TA","phoneCode":"+290"},{"name":"Tunisia","code":"TN","phoneCode":"+216"},{"name":"T\u00FCrkiye","code":"TR","phoneCode":"+90"},{"name":"Turkmenistan","code":"TM","phoneCode":"+993"},{"name":"Turks & Caicos Islands","code":"TC","phoneCode":"+1"},{"name":"Tuvalu","code":"TV","phoneCode":"+688"},{"name":"U.S. Virgin Islands","code":"VI","phoneCode":"+1"},{"name":"Uganda","code":"UG","phoneCode":"+256"},{"name":"Ukraine","code":"UA","phoneCode":"+380"},{"name":"United Arab Emirates","code":"AE","phoneCode":"+971"},{"name":"United Kingdom","code":"GB","phoneCode":"+44"},{"name":"United States","code":"US","phoneCode":"+1"},{"name":"Uruguay","code":"UY","phoneCode":"+598"},{"name":"Uzbekistan","code":"UZ","phoneCode":"+998"},{"name":"Vanuatu","code":"VU","phoneCode":"+678"},{"name":"Vatican City","code":"VA","phoneCode":"+39"},{"name":"Venezuela","code":"VE","phoneCode":"+58"},{"name":"Vietnam","code":"VN","phoneCode":"+84"},{"name":"Wallis & Futuna","code":"WF","phoneCode":"+681"},{"name":"Western Sahara","code":"EH","phoneCode":"+212"},{"name":"Yemen","code":"YE","phoneCode":"+967"},{"name":"Zambia","code":"ZM","phoneCode":"+260"},{"name":"Zimbabwe","code":"ZW","phoneCode":"+263"}]},"localizedStrings":{"validation":{"noValidSelection":"A valid selection must be made.","invalidUrl":"Must be a valid URL.","stringTooLong":"Value should have a length no longer than {0}.","containsInvalidKey":"{0} contains an invalid key.","invalidTwitterUsername":"Must be a valid Twitter username.","valueOutsideRange":"Value must be in the range {0} to {1}.","invalidPassword":"Passwords should not contain whitespace.","missingRequiredSubfields":"{0} is missing required subfields: {1}","invalidCurrency":"Currency value should be formatted like 1234 or 123.99.","invalidMapSize":"Value should contain exactly {0} elements.","subfieldsRequired":"All fields in {0} are required.","formSubmissionFailed":"Form submission failed. Review the following information: {0}.","invalidCountryCode":"Country code should have an optional plus and up to 4 digits.","invalidDate":"This is not a real date.","required":"{0} is required.","invalidStringLength":"Value should be {0} characters long.","invalidEmail":"Email addresses should follow the format user@domain.com.","invalidListLength":"Value should be {0} elements long.","allEmpty":"Please fill out at least one form field.","missingRequiredQuestion":"Missing a required question.","invalidQuestion":"Contained an invalid question.","captchaFailure":"Captcha validation failed. Please try again.","stringTooShort":"Value should have a length of at least {0}.","invalid":"{0} is not valid.","formErrors":"Form Errors","containsInvalidValue":"{0} contains an invalid value.","invalidUnsignedNumber":"Numbers must contain only digits and no other characters.","invalidName":"Valid names contain only letters, numbers, spaces, ', or - characters."},"submit":"Submit","status":{"title":"{@} Block","learnMore":"Learn more"},"name":{"firstName":"First Name","lastName":"Last Name"},"lightbox":{"openForm":"Open Form"},"likert":{"agree":"Agree","stronglyDisagree":"Strongly Disagree","disagree":"Disagree","stronglyAgree":"Strongly Agree","neutral":"Neutral"},"time":{"am":"AM","second":"Second","pm":"PM","minute":"Minute","amPm":"AM/PM","hour":"Hour"},"notFound":"Form not found.","date":{"yyyy":"YYYY","year":"Year","mm":"MM","day":"Day","month":"Month","dd":"DD"},"phone":{"country":"Country","number":"Number","prefix":"Prefix","areaCode":"Area Code","line":"Line"},"submitError":"Unable to submit form. Please try again later.","address":{"stateProvince":"State/Province","country":"Country","zipPostalCode":"Zip/Postal Code","address2":"Address 2","address1":"Address 1","city":"City"},"email":{"signUp":"Sign up for news and updates"},"required":"(required)","invalidData":"Invalid form data."}}};</script><script type="text/javascript">SQUARESPACE_ROLLUPS = {};</script>
<script>(function(rollups, name) { if (!rollups[name]) { rollups[name] = {}; } rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/visitor-site-error-reporter-e9c24af58b4efe13-min.en-US.js"]; })(SQUARESPACE_ROLLUPS, 'squarespace-visitor_site_error_reporter');</script>
<script crossorigin="anonymous" src="//assets.squarespace.com/universal/scripts-compressed/visitor-site-error-reporter-e9c24af58b4efe13-min.en-US.js" defer ></script><script>(function(rollups, name) { if (!rollups[name]) { rollups[name] = {}; } rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/extract-css-runtime-52bdcc642aae0df5-min.en-US.js"]; })(SQUARESPACE_ROLLUPS, 'squarespace-extract_css_runtime');</script>
<script crossorigin="anonymous" src="//assets.squarespace.com/universal/scripts-compressed/extract-css-runtime-52bdcc642aae0df5-min.en-US.js" defer ></script><script>(function(rollups, name) { if (!rollups[name]) { rollups[name] = {}; } rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/extract-css-moment-js-vendor-a5cfdec1ae227f33-min.en-US.js"]; })(SQUARESPACE_ROLLUPS, 'squarespace-extract_css_moment_js_vendor');</script>
<script crossorigin="anonymous" src="//assets.squarespace.com/universal/scripts-compressed/extract-css-moment-js-vendor-a5cfdec1ae227f33-min.en-US.js" defer ></script><script>(function(rollups, name) { if (!rollups[name]) { rollups[name] = {}; } rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/cldr-resource-pack-42a5d86b1fe8fbb5-min.en-US.js"]; })(SQUARESPACE_ROLLUPS, 'squarespace-cldr_resource_pack');</script>
<script crossorigin="anonymous" src="//assets.squarespace.com/universal/scripts-compressed/cldr-resource-pack-42a5d86b1fe8fbb5-min.en-US.js" defer ></script><script>(function(rollups, name) { if (!rollups[name]) { rollups[name] = {}; } rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/common-vendors-stable-1988b40b24a74586-min.en-US.js"]; })(SQUARESPACE_ROLLUPS, 'squarespace-common_vendors_stable');</script>
<script crossorigin="anonymous" src="//assets.squarespace.com/universal/scripts-compressed/common-vendors-stable-1988b40b24a74586-min.en-US.js" defer ></script><script>(function(rollups, name) { if (!rollups[name]) { rollups[name] = {}; } rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/common-vendors-bded37ca73fe21ab-min.en-US.js"]; })(SQUARESPACE_ROLLUPS, 'squarespace-common_vendors');</script>
<script crossorigin="anonymous" src="//assets.squarespace.com/universal/scripts-compressed/common-vendors-bded37ca73fe21ab-min.en-US.js" defer ></script><script>(function(rollups, name) { if (!rollups[name]) { rollups[name] = {}; } rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/common-734307a2e2bce8f2-min.en-US.js"]; })(SQUARESPACE_ROLLUPS, 'squarespace-common');</script>
<script crossorigin="anonymous" src="//assets.squarespace.com/universal/scripts-compressed/common-734307a2e2bce8f2-min.en-US.js" defer ></script><script>(function(rollups, name) { if (!rollups[name]) { rollups[name] = {}; } rollups[name].js = ["//assets.squarespace.com/universal/scripts-compressed/user-account-core-ca99048170e8f83d-min.en-US.js"]; })(SQUARESPACE_ROLLUPS, 'squarespace-user_account_core');</script>
<script crossorigin="anonymous" src="//assets.squarespace.com/universal/scripts-compressed/user-account-core-ca99048170e8f83d-min.en-US.js" defer ></script><script>(function(rollups, name) { if (!rollups[name]) { rollups[name] = {}; } rollups[name].css = ["//assets.squarespace.com/universal/styles-compressed/user-account-core-3d01a2f01227067c-min.en-US.css"]; })(SQUARESPACE_ROLLUPS, 'squarespace-user_account_core');</script>
<link rel="stylesheet" type="text/css" href="//assets.squarespace.com/universal/styles-compressed/user-account-core-3d01a2f01227067c-min.en-US.css"><link rel="stylesheet" type="text/css" href="https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.html/e4d8cee0-b2a8-4d2c-acaf-62c051981b6d_997/website.components.html.styles.css"/><link rel="stylesheet" type="text/css" href="https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.shape/48f8fea7-7663-4155-8a4f-74e7d943f820_1392/website.components.shape.styles.css"/><script defer src="https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.shape/48f8fea7-7663-4155-8a4f-74e7d943f820_1392/website.components.shape.visitor.js"></script><script defer src="https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.html/e4d8cee0-b2a8-4d2c-acaf-62c051981b6d_997/website.components.html.visitor.js"></script><script type="application/ld+json">{"url":"https://www.genglinyu.com","name":"Genglin Yu","description":"","image":"//images.squarespace-cdn.com/content/v1/6ad6ea4859e481727b113c39/af7d0cb8-e46e-462e-b1eb-871ba18b206f/logotype.png","@context":"http://schema.org","@type":"WebSite"}</script><link rel="stylesheet" type="text/css" href="https://static1.squarespace.com/static/versioned-site-css/6ad6ea4859e481727b113c39/28/5c5a519771c10ba3470d8101/6ad6ea4959e481727b113c74/1841/site.css?nocustom=true"/><link rel="stylesheet" type="text/css" href="https://static1.squarespace.com/static/vta/5c5a519771c10ba3470d8101/versioned-assets/1792079378326-3P84T29X62IH7QZWGRSR/static.css"/><link rel="stylesheet" type="text/css" href="https://static1.squarespace.com/static/custom-css/6ad6ea4859e481727b113c39/6ad6ea4959e481727b113c74/17/custom.css"/><script>Static.COOKIE_BANNER_CAPABLE = true;</script>
<!-- End of Squarespace Headers -->
    
    
  </head>

  <body
    id="not-found"
    class="
      primary-button-style-solid primary-button-shape-pill secondary-button-style-outline secondary-button-shape-pill tertiary-button-style-outline tertiary-button-shape-square form-field-style-solid form-field-shape-custom form-field-border-all form-field-hover-focus-opacity form-field-checkbox-type-icon form-field-checkbox-fill-solid form-field-checkbox-color-normal form-field-checkbox-shape-rounded form-field-checkbox-layout-fit form-field-radio-type-icon form-field-radio-fill-solid form-field-radio-color-normal form-field-radio-shape-rounded form-field-radio-layout-fit form-field-survey-fill-solid form-field-survey-color-normal form-field-survey-shape-rounded form-submit-button-style-spinner tweak-global-animations-animation-type-none tweak-global-animations-animation-curve-ease image-block-poster-text-alignment-center image-block-card-content-position-center image-block-card-text-alignment-left image-block-overlap-content-position-center image-block-overlap-text-alignment-left image-block-collage-content-position-center image-block-collage-text-alignment-left image-block-stack-text-alignment-left tweak-blog-alternating-side-by-side-width-full tweak-blog-alternating-side-by-side-image-aspect-ratio-11-square tweak-blog-alternating-side-by-side-text-alignment-left tweak-blog-alternating-side-by-side-read-more-style-show tweak-blog-alternating-side-by-side-image-text-alignment-middle tweak-blog-alternating-side-by-side-delimiter-bullet tweak-blog-alternating-side-by-side-meta-position-top tweak-blog-alternating-side-by-side-primary-meta-categories tweak-blog-alternating-side-by-side-secondary-meta-date tweak-blog-alternating-side-by-side-excerpt-show form-use-theme-colors tweak-global-animations-complexity-level-detailed tweak-global-animations-animation-style-fade tweak-blog-masonry-width-full tweak-blog-masonry-text-alignment-left tweak-blog-masonry-primary-meta-categories tweak-blog-masonry-secondary-meta-date tweak-blog-masonry-meta-position-top tweak-blog-masonry-read-more-style-show tweak-blog-masonry-delimiter-space tweak-blog-masonry-image-placement-above tweak-blog-masonry-excerpt-show tweak-portfolio-grid-overlay-width-full tweak-portfolio-grid-overlay-height-large tweak-portfolio-grid-overlay-image-aspect-ratio-11-square tweak-portfolio-grid-overlay-text-placement-center tweak-portfolio-grid-overlay-show-text-after-hover tweak-blog-single-column-width-full tweak-blog-single-column-text-alignment-center tweak-blog-single-column-image-placement-above tweak-blog-single-column-delimiter-bullet tweak-blog-single-column-read-more-style-show tweak-blog-single-column-primary-meta-date tweak-blog-single-column-secondary-meta-categories tweak-blog-single-column-meta-position-top tweak-blog-single-column-content-title-only header-width-inset  tweak-fixed-header-style-basic tweak-blog-item-width-medium tweak-blog-item-text-alignment-center tweak-blog-item-meta-position-above-title tweak-blog-item-show-categories tweak-blog-item-show-date tweak-blog-item-delimiter-bullet tweak-blog-side-by-side-width-full tweak-blog-side-by-side-image-placement-left tweak-blog-side-by-side-image-aspect-ratio-11-square tweak-blog-side-by-side-primary-meta-categories tweak-blog-side-by-side-secondary-meta-date tweak-blog-side-by-side-meta-position-top tweak-blog-side-by-side-text-alignment-left tweak-blog-side-by-side-image-text-alignment-middle tweak-blog-side-by-side-read-more-style-show tweak-blog-side-by-side-delimiter-bullet tweak-blog-side-by-side-excerpt-show tweak-events-stacked-width-full tweak-events-stacked-height-large tweak-events-stacked-show-thumbnails tweak-events-stacked-thumbnail-size-32-standard tweak-events-stacked-date-style-with-text tweak-events-stacked-show-time tweak-events-stacked-show-location tweak-events-stacked-show-excerpt tweak-blog-basic-grid-width-inset tweak-blog-basic-grid-image-aspect-ratio-32-standard tweak-blog-basic-grid-text-alignment-left tweak-blog-basic-grid-delimiter-bullet tweak-blog-basic-grid-image-placement-above tweak-blog-basic-grid-read-more-style-show tweak-blog-basic-grid-primary-meta-date tweak-blog-basic-grid-secondary-meta-categories tweak-blog-basic-grid-excerpt-show tweak-portfolio-grid-basic-width-full tweak-portfolio-grid-basic-height-large tweak-portfolio-grid-basic-image-aspect-ratio-11-square tweak-portfolio-grid-basic-text-alignment-left tweak-portfolio-grid-basic-hover-effect-fade header-overlay-alignment-center tweak-portfolio-index-background-link-format-stacked tweak-portfolio-index-background-width-full tweak-portfolio-index-background-height-large tweak-portfolio-index-background-vertical-alignment-middle tweak-portfolio-index-background-horizontal-alignment-center tweak-portfolio-index-background-delimiter-none tweak-portfolio-index-background-animation-type-fade tweak-portfolio-index-background-animation-duration-medium tweak-portfolio-hover-follow-layout-inline tweak-portfolio-hover-follow-delimiter-bullet tweak-portfolio-hover-follow-animation-type-fade tweak-portfolio-hover-follow-animation-duration-fast tweak-portfolio-hover-static-layout-inline tweak-portfolio-hover-static-front tweak-portfolio-hover-static-delimiter-hyphen tweak-portfolio-hover-static-animation-type-fade tweak-portfolio-hover-static-animation-duration-fast hide-opentable-icons opentable-style-dark tweak-product-quick-view-button-style-floating tweak-product-quick-view-button-position-bottom tweak-product-quick-view-lightbox-excerpt-display-truncate tweak-product-quick-view-lightbox-show-arrows tweak-product-quick-view-lightbox-show-close-button tweak-product-quick-view-lightbox-controls-weight-light native-currency-code-usd not-found-page mobile-style-available sqs-seven-one
      
        
      
    "
    tabindex="-1"
  >
    <div
      id="siteWrapper"
      class="clearfix site-wrapper"
    >
      
        <div id="floatingCart" class="floating-cart hidden">
          <a href="/cart" class="icon icon--stroke icon--fill icon--cart sqs-custom-cart">
            <span class="Cart-inner">
              



  <svg class="icon icon--cart" width="61" height="49" viewBox="0 0 61 49">
  <path fill-rule="evenodd" clip-rule="evenodd" d="M0.5 2C0.5 1.17157 1.17157 0.5 2 0.5H13.6362C14.3878 0.5 15.0234 1.05632 15.123 1.80135L16.431 11.5916H59C59.5122 11.5916 59.989 11.8529 60.2645 12.2847C60.54 12.7165 60.5762 13.2591 60.3604 13.7236L50.182 35.632C49.9361 36.1614 49.4054 36.5 48.8217 36.5H18.0453C17.2937 36.5 16.6581 35.9437 16.5585 35.1987L12.3233 3.5H2C1.17157 3.5 0.5 2.82843 0.5 2ZM16.8319 14.5916L19.3582 33.5H47.8646L56.6491 14.5916H16.8319Z" />
  <path d="M18.589 35H49.7083L60 13H16L18.589 35Z" />
  <path d="M21 49C23.2091 49 25 47.2091 25 45C25 42.7909 23.2091 41 21 41C18.7909 41 17 42.7909 17 45C17 47.2091 18.7909 49 21 49Z" />
  <path d="M45 49C47.2091 49 49 47.2091 49 45C49 42.7909 47.2091 41 45 41C42.7909 41 41 42.7909 41 45C41 47.2091 42.7909 49 45 49Z" />
</svg>

              <div class="legacy-cart icon-cart-quantity">
                <span class="sqs-cart-quantity">0</span>
              </div>
            </span>
          </a>
        </div>
      

      












  <header
    data-test="header"
    id="header"
    
    class="
      
        
      
      header theme-col--primary
    "
    data-section-theme=""
    data-controller="Header"
    data-current-styles="{
                                &quot;layout&quot;: &quot;navRight&quot;,
                                &quot;action&quot;: {
                                  &quot;href&quot;: &quot;/appointments&quot;,
                                  &quot;buttonText&quot;: &quot;Book Now&quot;,
                                  &quot;newWindow&quot;: false
                                },
                                &quot;showSocial&quot;: true,
                                &quot;socialOptions&quot;: {
                                  &quot;socialBorderShape&quot;: &quot;none&quot;,
                                  &quot;socialBorderStyle&quot;: &quot;outline&quot;,
                                  &quot;socialBorderThickness&quot;: {
                                    &quot;unit&quot;: &quot;px&quot;,
                                    &quot;value&quot;: 1.0
                                  }
                                },
                                &quot;menuOverlayAnimation&quot;: &quot;fade&quot;,
                                &quot;cartStyle&quot;: &quot;cart&quot;,
                                &quot;cartText&quot;: &quot;Cart&quot;,
                                &quot;showEmptyCartState&quot;: true,
                                &quot;cartOptions&quot;: {
                                  &quot;iconType&quot;: &quot;solid-7&quot;,
                                  &quot;cartBorderShape&quot;: &quot;none&quot;,
                                  &quot;cartBorderStyle&quot;: &quot;outline&quot;,
                                  &quot;cartBorderThickness&quot;: {
                                    &quot;unit&quot;: &quot;px&quot;,
                                    &quot;value&quot;: 1.0
                                  }
                                },
                                &quot;showButton&quot;: false,
                                &quot;showCart&quot;: false,
                                &quot;showAccountLogin&quot;: false,
                                &quot;headerStyle&quot;: &quot;solid&quot;,
                                &quot;languagePicker&quot;: {
                                  &quot;enabled&quot;: false,
                                  &quot;iconEnabled&quot;: false,
                                  &quot;iconType&quot;: &quot;globe&quot;,
                                  &quot;flagShape&quot;: &quot;shiny&quot;,
                                  &quot;languageFlags&quot;: [ ]
                                },
                                &quot;iconOptions&quot;: {
                                  &quot;desktopDropdownIconOptions&quot;: {
                                    &quot;size&quot;: {
                                      &quot;unit&quot;: &quot;em&quot;,
                                      &quot;value&quot;: 1.0
                                    },
                                    &quot;iconSpacing&quot;: {
                                      &quot;unit&quot;: &quot;em&quot;,
                                      &quot;value&quot;: 0.35
                                    },
                                    &quot;strokeWidth&quot;: {
                                      &quot;unit&quot;: &quot;px&quot;,
                                      &quot;value&quot;: 1.0
                                    },
                                    &quot;endcapType&quot;: &quot;square&quot;,
                                    &quot;folderDropdownIcon&quot;: &quot;none&quot;,
                                    &quot;languagePickerIcon&quot;: &quot;openArrowHead&quot;
                                  },
                                  &quot;mobileDropdownIconOptions&quot;: {
                                    &quot;size&quot;: {
                                      &quot;unit&quot;: &quot;em&quot;,
                                      &quot;value&quot;: 1.0
                                    },
                                    &quot;iconSpacing&quot;: {
                                      &quot;unit&quot;: &quot;em&quot;,
                                      &quot;value&quot;: 0.15
                                    },
                                    &quot;strokeWidth&quot;: {
                                      &quot;unit&quot;: &quot;px&quot;,
                                      &quot;value&quot;: 0.5
                                    },
                                    &quot;endcapType&quot;: &quot;square&quot;,
                                    &quot;folderDropdownIcon&quot;: &quot;openArrowHead&quot;,
                                    &quot;languagePickerIcon&quot;: &quot;openArrowHead&quot;
                                  }
                                },
                                &quot;mobileOptions&quot;: {
                                  &quot;layout&quot;: &quot;logoLeftNavRight&quot;,
                                  &quot;menuIconOptions&quot;: {
                                    &quot;style&quot;: &quot;doubleLineHamburger&quot;,
                                    &quot;thickness&quot;: {
                                      &quot;unit&quot;: &quot;px&quot;,
                                      &quot;value&quot;: 1.0
                                    }
                                  }
                                },
                                &quot;solidOptions&quot;: {
                                  &quot;headerOpacity&quot;: {
                                    &quot;unit&quot;: &quot;%&quot;,
                                    &quot;value&quot;: 100.0
                                  },
                                  &quot;blurBackground&quot;: {
                                    &quot;enabled&quot;: false,
                                    &quot;blurRadius&quot;: {
                                      &quot;unit&quot;: &quot;px&quot;,
                                      &quot;value&quot;: 12.0
                                    }
                                  },
                                  &quot;backgroundColor&quot;: {
                                    &quot;type&quot;: &quot;SITE_PALETTE_COLOR&quot;,
                                    &quot;sitePaletteColor&quot;: {
                                      &quot;colorName&quot;: &quot;white&quot;,
                                      &quot;alphaModifier&quot;: 1.0
                                    }
                                  },
                                  &quot;navigationColor&quot;: {
                                    &quot;type&quot;: &quot;SITE_PALETTE_COLOR&quot;,
                                    &quot;sitePaletteColor&quot;: {
                                      &quot;colorName&quot;: &quot;black&quot;,
                                      &quot;alphaModifier&quot;: 1.0
                                    }
                                  }
                                },
                                &quot;gradientOptions&quot;: {
                                  &quot;gradientType&quot;: &quot;faded&quot;,
                                  &quot;headerOpacity&quot;: {
                                    &quot;unit&quot;: &quot;%&quot;,
                                    &quot;value&quot;: 90.0
                                  },
                                  &quot;blurBackground&quot;: {
                                    &quot;enabled&quot;: false,
                                    &quot;blurRadius&quot;: {
                                      &quot;unit&quot;: &quot;px&quot;,
                                      &quot;value&quot;: 12.0
                                    }
                                  },
                                  &quot;backgroundColor&quot;: {
                                    &quot;type&quot;: &quot;SITE_PALETTE_COLOR&quot;,
                                    &quot;sitePaletteColor&quot;: {
                                      &quot;colorName&quot;: &quot;lightAccent&quot;,
                                      &quot;alphaModifier&quot;: 1.0
                                    }
                                  },
                                  &quot;navigationColor&quot;: {
                                    &quot;type&quot;: &quot;SITE_PALETTE_COLOR&quot;,
                                    &quot;sitePaletteColor&quot;: {
                                      &quot;colorName&quot;: &quot;accent&quot;,
                                      &quot;alphaModifier&quot;: 1.0
                                    }
                                  }
                                },
                                &quot;dropShadowOptions&quot;: {
                                  &quot;enabled&quot;: false,
                                  &quot;blur&quot;: {
                                    &quot;unit&quot;: &quot;px&quot;,
                                    &quot;value&quot;: 12.0
                                  },
                                  &quot;spread&quot;: {
                                    &quot;unit&quot;: &quot;px&quot;,
                                    &quot;value&quot;: 0.0
                                  },
                                  &quot;distance&quot;: {
                                    &quot;unit&quot;: &quot;px&quot;,
                                    &quot;value&quot;: 12.0
                                  }
                                },
                                &quot;borderOptions&quot;: {
                                  &quot;enabled&quot;: false,
                                  &quot;position&quot;: &quot;allSides&quot;,
                                  &quot;thickness&quot;: {
                                    &quot;unit&quot;: &quot;px&quot;,
                                    &quot;value&quot;: 4.0
                                  },
                                  &quot;color&quot;: {
                                    &quot;type&quot;: &quot;SITE_PALETTE_COLOR&quot;,
                                    &quot;sitePaletteColor&quot;: {
                                      &quot;colorName&quot;: &quot;black&quot;,
                                      &quot;alphaModifier&quot;: 1.0
                                    }
                                  }
                                },
                                &quot;showPromotedElement&quot;: false,
                                &quot;buttonVariant&quot;: &quot;primary&quot;,
                                &quot;blurBackground&quot;: {
                                  &quot;enabled&quot;: false,
                                  &quot;blurRadius&quot;: {
                                    &quot;unit&quot;: &quot;px&quot;,
                                    &quot;value&quot;: 12.0
                                  }
                                },
                                &quot;headerOpacity&quot;: {
                                  &quot;unit&quot;: &quot;%&quot;,
                                  &quot;value&quot;: 100.0
                                }
                              }"
    data-section-id="header"
    data-header-style="solid"
    data-language-picker="{
                                &quot;enabled&quot;: false,
                                &quot;iconEnabled&quot;: false,
                                &quot;iconType&quot;: &quot;globe&quot;,
                                &quot;flagShape&quot;: &quot;shiny&quot;,
                                &quot;languageFlags&quot;: [ ]
                              }"
    
    
    data-first-focusable-element
    tabindex="-1"
    style="
      
      
        --headerBorderColor: hsla(var(--black-hsl), 1);
      
      
        --solidHeaderBackgroundColor: hsla(var(--white-hsl), 1);
      
      
        --solidHeaderNavigationColor: hsla(var(--black-hsl), 1);
      
      
        --gradientHeaderBackgroundColor: hsla(var(--lightAccent-hsl), 1);
      
      
        --gradientHeaderNavigationColor: hsla(var(--accent-hsl), 1);
      
    "
  >
    <svg  style="display:none" viewBox="0 0 22 22" xmlns="http://www.w3.org/2000/svg">
  <symbol id="circle" >
    <path d="M11.5 17C14.5376 17 17 14.5376 17 11.5C17 8.46243 14.5376 6 11.5 6C8.46243 6 6 8.46243 6 11.5C6 14.5376 8.46243 17 11.5 17Z" fill="none" />
  </symbol>

  <symbol id="circleFilled" >
    <path d="M11.5 17C14.5376 17 17 14.5376 17 11.5C17 8.46243 14.5376 6 11.5 6C8.46243 6 6 8.46243 6 11.5C6 14.5376 8.46243 17 11.5 17Z" />
  </symbol>

  <symbol id="dash" >
    <path d="M11 11H19H3" />
  </symbol>

  <symbol id="squareFilled" >
    <rect x="6" y="6" width="11" height="11" />
  </symbol>

  <symbol id="square" >
    <rect x="7" y="7" width="9" height="9" fill="none" stroke="inherit" />
  </symbol>
  
  <symbol id="plus" >
    <path d="M11 3V19" />
    <path d="M19 11L3 11"/>
  </symbol>
  
  <symbol id="closedArrow" >
    <path d="M11 11V2M11 18.1797L17 11.1477L5 11.1477L11 18.1797Z" fill="none" />
  </symbol>
  
  <symbol id="closedArrowFilled" >
    <path d="M11 11L11 2" stroke="inherit" fill="none"  />
    <path fill-rule="evenodd" clip-rule="evenodd" d="M2.74695 9.38428L19.038 9.38428L10.8925 19.0846L2.74695 9.38428Z" stroke-width="1" />
  </symbol>
  
  <symbol id="closedArrowHead" viewBox="0 0 22 22"  xmlns="http://www.w3.org/2000/symbol">
    <path d="M18 7L11 15L4 7L18 7Z" fill="none" stroke="inherit" />
  </symbol>
  
  
  <symbol id="closedArrowHeadFilled" viewBox="0 0 22 22"  xmlns="http://www.w3.org/2000/symbol">
    <path d="M18.875 6.5L11 15.5L3.125 6.5L18.875 6.5Z" />
  </symbol>
  
  <symbol id="openArrow" >
    <path d="M11 18.3591L11 3" stroke="inherit" fill="none"  />
    <path d="M18 11.5L11 18.5L4 11.5" stroke="inherit" fill="none"  />
  </symbol>
  
  <symbol id="openArrowHead" >
    <path d="M18 7L11 14L4 7" fill="none" />
  </symbol>

  <symbol id="pinchedArrow" >
    <path d="M11 17.3591L11 2" fill="none" />
    <path d="M2 11C5.85455 12.2308 8.81818 14.9038 11 18C13.1818 14.8269 16.1455 12.1538 20 11" fill="none" />
  </symbol>

  <symbol id="pinchedArrowFilled" >
    <path d="M11.05 10.4894C7.04096 8.73759 1.05005 8 1.05005 8C6.20459 11.3191 9.41368 14.1773 11.05 21C12.6864 14.0851 15.8955 11.227 21.05 8C21.05 8 15.0591 8.73759 11.05 10.4894Z" stroke-width="1"/>
    <path d="M11 11L11 1" fill="none"/>
  </symbol>

  <symbol id="pinchedArrowHead" >
    <path d="M2 7.24091C5.85455 8.40454 8.81818 10.9318 11 13.8591C13.1818 10.8591 16.1455 8.33181 20 7.24091"  fill="none" />
  </symbol>
  
  <symbol id="pinchedArrowHeadFilled" >
    <path d="M11.05 7.1591C7.04096 5.60456 1.05005 4.95001 1.05005 4.95001C6.20459 7.89547 9.41368 10.4318 11.05 16.4864C12.6864 10.35 15.8955 7.81365 21.05 4.95001C21.05 4.95001 15.0591 5.60456 11.05 7.1591Z" />
  </symbol>

</svg>
    
<div class="sqs-announcement-bar-dropzone"></div>

    <div class="header-announcement-bar-wrapper">
      
      <a
        href="#page"
        class="header-skip-link sqs-button-element--primary"
      >
        Skip to Content
      </a>
      


<style>
    @supports (-webkit-backdrop-filter: none) or (backdrop-filter: none) {
        .header-blur-background {
            
                -webkit-backdrop-filter: blur(12px);
                backdrop-filter: blur(12px);
            
            
        }
    }
</style>
      <div
        class="header-border"
        data-header-style="solid"
        data-header-border="false"
        data-test="header-border"
        style="




"
      ></div>
      <div
        class="header-dropshadow"
        data-header-style="solid"
        data-header-dropshadow="false"
        data-test="header-dropshadow"
        style=""
      ></div>
      
      
        <div >
          <div
            class="header-background-solid"
            data-header-style="solid"
            data-test="header-background-solid"
            
            
            style="opacity: calc(100 * .01)"
          ></div>
        </div>
      

      <div class='header-inner container--fluid
        
        
        
         header-mobile-layout-logo-left-nav-right
        
        
        
        
        
        
         header-layout-nav-right
        
        
        
        
        
        
        
        
        '
        data-test="header-inner"
        >
        <!-- Background -->
        <div class="header-background theme-bg--primary"></div>

        <div class="header-display-desktop" data-content-field="site-title">
          

          

          

          

          

          
          
            
            <!-- Social -->
            
              
            
          
            
            <!-- Title and nav wrapper -->
            <div class="header-title-nav-wrapper">
              

              

              
                
                <!-- Title -->
                
                  <div
                    class="
                      header-title
                      
                    "
                    data-animation-role="header-element"
                  >
                    
                      <div class="header-title-logo">
                        <a href="/" data-animation-role="header-element">
                        
<img elementtiming="nbf-header-logo-desktop" src="//images.squarespace-cdn.com/content/v1/6ad6ea4859e481727b113c39/af7d0cb8-e46e-462e-b1eb-871ba18b206f/logotype.png?format=1500w" alt="Genglin Yu" style="display:block" fetchpriority="high" loading="eager" decoding="async" data-loader="raw">

                        </a>
                      </div>

                    
                    
                  </div>
                
              
                
                <!-- Nav -->
                <div class="header-nav">
                  <div class="header-nav-wrapper">
                    <nav class="header-nav-list">
                      

                    </nav>
                  </div>
                </div>
              
              
            </div>
          
            
            <!-- Actions -->
            <div class="header-actions header-actions--right">
              
                
              
              
                
                  <div class="header-actions-action header-actions-action--social">
                    
                      
                        <a class="icon icon--fill  header-icon header-icon-border-shape-none header-icon-border-style-outline"  href="https://www.instagram.com/yu.genglin/" target="_blank" aria-label="Instagram">
                          <svg viewBox="23 23 64 64">
                            <use xlink:href="#instagram-unauth-icon" width="110" height="110"></use>
                          </svg>
                        </a>
                      
                        <a class="icon icon--fill  header-icon header-icon-border-shape-none header-icon-border-style-outline"  href="http://twitter.com/squarespacehttps://www.linkedin.com/in/genglin-yu/?isSelfProfile=true" target="_blank" aria-label="LinkedIn">
                          <svg viewBox="23 23 64 64">
                            <use xlink:href="#linkedin-unauth-icon" width="110" height="110"></use>
                          </svg>
                        </a>
                      
                        <a class="icon icon--fill  header-icon header-icon-border-shape-none header-icon-border-style-outline"  href="https://www.facebook.com/profile.php?id=100009310393967" target="_blank" aria-label="Facebook">
                          <svg viewBox="23 23 64 64">
                            <use xlink:href="#facebook-unauth-icon" width="110" height="110"></use>
                          </svg>
                        </a>
                      
                    
                  </div>
                
              

              

            
            

              
              <div class="showOnMobile">
                
              </div>

              
              <div class="showOnDesktop">
                
              </div>

              
            </div>
          
            


<style>
  .top-bun, 
  .patty, 
  .bottom-bun {
    height: 1px;
  }
</style>

<!-- Burger -->
<div class="header-burger

  menu-overlay-has-visible-non-navigation-items

" data-animation-role="header-element">
  <button class="header-burger-btn burger" data-test="header-burger">
    <span hidden class="js-header-burger-open-title visually-hidden">Open Menu</span>
    <span hidden class="js-header-burger-close-title visually-hidden">Close Menu</span>
    <div class="burger-box">
      <div class="burger-inner header-menu-icon-doubleLineHamburger">
        <div class="top-bun"></div>
        <div class="patty"></div>
        <div class="bottom-bun"></div>
      </div>
    </div>
  </button>
</div>

          

        </div>
        <div class="header-display-mobile" data-content-field="site-title">
          
            
            <!-- Social -->
            
              
            
          
            
            <!-- Title and nav wrapper -->
            <div class="header-title-nav-wrapper">
              

              

              
                
                <!-- Title -->
                
                  <div
                    class="
                      header-title
                      
                    "
                    data-animation-role="header-element"
                  >
                    
                      <div class="header-title-logo">
                        <a href="/" data-animation-role="header-element">
                        
<img elementtiming="nbf-header-logo-desktop" src="//images.squarespace-cdn.com/content/v1/6ad6ea4859e481727b113c39/af7d0cb8-e46e-462e-b1eb-871ba18b206f/logotype.png?format=1500w" alt="Genglin Yu" style="display:block" fetchpriority="high" loading="eager" decoding="async" data-loader="raw">

                        </a>
                      </div>

                    
                    
                  </div>
                
              
                
                <!-- Nav -->
                <div class="header-nav">
                  <div class="header-nav-wrapper">
                    <nav class="header-nav-list">
                      

                    </nav>
                  </div>
                </div>
              
              
            </div>
          
            
            <!-- Actions -->
            <div class="header-actions header-actions--right">
              
                
              
              
                
                  <div class="header-actions-action header-actions-action--social">
                    
                      
                        <a class="icon icon--fill  header-icon header-icon-border-shape-none header-icon-border-style-outline"  href="https://www.instagram.com/yu.genglin/" target="_blank" aria-label="Instagram">
                          <svg viewBox="23 23 64 64">
                            <use xlink:href="#instagram-unauth-icon" width="110" height="110"></use>
                          </svg>
                        </a>
                      
                        <a class="icon icon--fill  header-icon header-icon-border-shape-none header-icon-border-style-outline"  href="http://twitter.com/squarespacehttps://www.linkedin.com/in/genglin-yu/?isSelfProfile=true" target="_blank" aria-label="LinkedIn">
                          <svg viewBox="23 23 64 64">
                            <use xlink:href="#linkedin-unauth-icon" width="110" height="110"></use>
                          </svg>
                        </a>
                      
                        <a class="icon icon--fill  header-icon header-icon-border-shape-none header-icon-border-style-outline"  href="https://www.facebook.com/profile.php?id=100009310393967" target="_blank" aria-label="Facebook">
                          <svg viewBox="23 23 64 64">
                            <use xlink:href="#facebook-unauth-icon" width="110" height="110"></use>
                          </svg>
                        </a>
                      
                    
                  </div>
                
              

              

            
            

              
              <div class="showOnMobile">
                
              </div>

              
              <div class="showOnDesktop">
                
              </div>

              
            </div>
          
            


<style>
  .top-bun, 
  .patty, 
  .bottom-bun {
    height: 1px;
  }
</style>

<!-- Burger -->
<div class="header-burger

  menu-overlay-has-visible-non-navigation-items

" data-animation-role="header-element">
  <button class="header-burger-btn burger" data-test="header-burger">
    <span hidden class="js-header-burger-open-title visually-hidden">Open Menu</span>
    <span hidden class="js-header-burger-close-title visually-hidden">Close Menu</span>
    <div class="burger-box">
      <div class="burger-inner header-menu-icon-doubleLineHamburger">
        <div class="top-bun"></div>
        <div class="patty"></div>
        <div class="bottom-bun"></div>
      </div>
    </div>
  </button>
</div>

          
          
          
          
          
        </div>
      </div>
    </div>
    <!-- (Mobile) Menu Navigation -->
    <div class="header-menu header-menu--folder-list
      
      
      
      
      
      "
      data-section-theme=""
      data-current-styles="{
                                &quot;layout&quot;: &quot;navRight&quot;,
                                &quot;action&quot;: {
                                  &quot;href&quot;: &quot;/appointments&quot;,
                                  &quot;buttonText&quot;: &quot;Book Now&quot;,
                                  &quot;newWindow&quot;: false
                                },
                                &quot;showSocial&quot;: true,
                                &quot;socialOptions&quot;: {
                                  &quot;socialBorderShape&quot;: &quot;none&quot;,
                                  &quot;socialBorderStyle&quot;: &quot;outline&quot;,
                                  &quot;socialBorderThickness&quot;: {
                                    &quot;unit&quot;: &quot;px&quot;,
                                    &quot;value&quot;: 1.0
                                  }
                                },
                                &quot;menuOverlayAnimation&quot;: &quot;fade&quot;,
                                &quot;cartStyle&quot;: &quot;cart&quot;,
                                &quot;cartText&quot;: &quot;Cart&quot;,
                                &quot;showEmptyCartState&quot;: true,
                                &quot;cartOptions&quot;: {
                                  &quot;iconType&quot;: &quot;solid-7&quot;,
                                  &quot;cartBorderShape&quot;: &quot;none&quot;,
                                  &quot;cartBorderStyle&quot;: &quot;outline&quot;,
                                  &quot;cartBorderThickness&quot;: {
                                    &quot;unit&quot;: &quot;px&quot;,
                                    &quot;value&quot;: 1.0
                                  }
                                },
                                &quot;showButton&quot;: false,
                                &quot;showCart&quot;: false,
                                &quot;showAccountLogin&quot;: false,
                                &quot;headerStyle&quot;: &quot;solid&quot;,
                                &quot;languagePicker&quot;: {
                                  &quot;enabled&quot;: false,
                                  &quot;iconEnabled&quot;: false,
                                  &quot;iconType&quot;: &quot;globe&quot;,
                                  &quot;flagShape&quot;: &quot;shiny&quot;,
                                  &quot;languageFlags&quot;: [ ]
                                },
                                &quot;iconOptions&quot;: {
                                  &quot;desktopDropdownIconOptions&quot;: {
                                    &quot;size&quot;: {
                                      &quot;unit&quot;: &quot;em&quot;,
                                      &quot;value&quot;: 1.0
                                    },
                                    &quot;iconSpacing&quot;: {
                                      &quot;unit&quot;: &quot;em&quot;,
                                      &quot;value&quot;: 0.35
                                    },
                                    &quot;strokeWidth&quot;: {
                                      &quot;unit&quot;: &quot;px&quot;,
                                      &quot;value&quot;: 1.0
                                    },
                                    &quot;endcapType&quot;: &quot;square&quot;,
                                    &quot;folderDropdownIcon&quot;: &quot;none&quot;,
                                    &quot;languagePickerIcon&quot;: &quot;openArrowHead&quot;
                                  },
                                  &quot;mobileDropdownIconOptions&quot;: {
                                    &quot;size&quot;: {
                                      &quot;unit&quot;: &quot;em&quot;,
                                      &quot;value&quot;: 1.0
                                    },
                                    &quot;iconSpacing&quot;: {
                                      &quot;unit&quot;: &quot;em&quot;,
                                      &quot;value&quot;: 0.15
                                    },
                                    &quot;strokeWidth&quot;: {
                                      &quot;unit&quot;: &quot;px&quot;,
                                      &quot;value&quot;: 0.5
                                    },
                                    &quot;endcapType&quot;: &quot;square&quot;,
                                    &quot;folderDropdownIcon&quot;: &quot;openArrowHead&quot;,
                                    &quot;languagePickerIcon&quot;: &quot;openArrowHead&quot;
                                  }
                                },
                                &quot;mobileOptions&quot;: {
                                  &quot;layout&quot;: &quot;logoLeftNavRight&quot;,
                                  &quot;menuIconOptions&quot;: {
                                    &quot;style&quot;: &quot;doubleLineHamburger&quot;,
                                    &quot;thickness&quot;: {
                                      &quot;unit&quot;: &quot;px&quot;,
                                      &quot;value&quot;: 1.0
                                    }
                                  }
                                },
                                &quot;solidOptions&quot;: {
                                  &quot;headerOpacity&quot;: {
                                    &quot;unit&quot;: &quot;%&quot;,
                                    &quot;value&quot;: 100.0
                                  },
                                  &quot;blurBackground&quot;: {
                                    &quot;enabled&quot;: false,
                                    &quot;blurRadius&quot;: {
                                      &quot;unit&quot;: &quot;px&quot;,
                                      &quot;value&quot;: 12.0
                                    }
                                  },
                                  &quot;backgroundColor&quot;: {
                                    &quot;type&quot;: &quot;SITE_PALETTE_COLOR&quot;,
                                    &quot;sitePaletteColor&quot;: {
                                      &quot;colorName&quot;: &quot;white&quot;,
                                      &quot;alphaModifier&quot;: 1.0
                                    }
                                  },
                                  &quot;navigationColor&quot;: {
                                    &quot;type&quot;: &quot;SITE_PALETTE_COLOR&quot;,
                                    &quot;sitePaletteColor&quot;: {
                                      &quot;colorName&quot;: &quot;black&quot;,
                                      &quot;alphaModifier&quot;: 1.0
                                    }
                                  }
                                },
                                &quot;gradientOptions&quot;: {
                                  &quot;gradientType&quot;: &quot;faded&quot;,
                                  &quot;headerOpacity&quot;: {
                                    &quot;unit&quot;: &quot;%&quot;,
                                    &quot;value&quot;: 90.0
                                  },
                                  &quot;blurBackground&quot;: {
                                    &quot;enabled&quot;: false,
                                    &quot;blurRadius&quot;: {
                                      &quot;unit&quot;: &quot;px&quot;,
                                      &quot;value&quot;: 12.0
                                    }
                                  },
                                  &quot;backgroundColor&quot;: {
                                    &quot;type&quot;: &quot;SITE_PALETTE_COLOR&quot;,
                                    &quot;sitePaletteColor&quot;: {
                                      &quot;colorName&quot;: &quot;lightAccent&quot;,
                                      &quot;alphaModifier&quot;: 1.0
                                    }
                                  },
                                  &quot;navigationColor&quot;: {
                                    &quot;type&quot;: &quot;SITE_PALETTE_COLOR&quot;,
                                    &quot;sitePaletteColor&quot;: {
                                      &quot;colorName&quot;: &quot;accent&quot;,
                                      &quot;alphaModifier&quot;: 1.0
                                    }
                                  }
                                },
                                &quot;dropShadowOptions&quot;: {
                                  &quot;enabled&quot;: false,
                                  &quot;blur&quot;: {
                                    &quot;unit&quot;: &quot;px&quot;,
                                    &quot;value&quot;: 12.0
                                  },
                                  &quot;spread&quot;: {
                                    &quot;unit&quot;: &quot;px&quot;,
                                    &quot;value&quot;: 0.0
                                  },
                                  &quot;distance&quot;: {
                                    &quot;unit&quot;: &quot;px&quot;,
                                    &quot;value&quot;: 12.0
                                  }
                                },
                                &quot;borderOptions&quot;: {
                                  &quot;enabled&quot;: false,
                                  &quot;position&quot;: &quot;allSides&quot;,
                                  &quot;thickness&quot;: {
                                    &quot;unit&quot;: &quot;px&quot;,
                                    &quot;value&quot;: 4.0
                                  },
                                  &quot;color&quot;: {
                                    &quot;type&quot;: &quot;SITE_PALETTE_COLOR&quot;,
                                    &quot;sitePaletteColor&quot;: {
                                      &quot;colorName&quot;: &quot;black&quot;,
                                      &quot;alphaModifier&quot;: 1.0
                                    }
                                  }
                                },
                                &quot;showPromotedElement&quot;: false,
                                &quot;buttonVariant&quot;: &quot;primary&quot;,
                                &quot;blurBackground&quot;: {
                                  &quot;enabled&quot;: false,
                                  &quot;blurRadius&quot;: {
                                    &quot;unit&quot;: &quot;px&quot;,
                                    &quot;value&quot;: 12.0
                                  }
                                },
                                &quot;headerOpacity&quot;: {
                                  &quot;unit&quot;: &quot;%&quot;,
                                  &quot;value&quot;: 100.0
                                }
                              }"
      data-section-id="overlay-nav"
      data-show-account-login="false"
      data-test="header-menu">
      <div class="header-menu-bg theme-bg--primary"></div>
      <div class="header-menu-nav">
        <nav class="header-menu-nav-list">
          <div data-folder="root" class="header-menu-nav-folder">
            <div class="header-menu-nav-folder-content">
              <!-- Menu Navigation -->
<div class="header-menu-nav-wrapper">
  
</div>

              
                
              
            </div>
            
              <div class="header-menu-actions social-accounts">
                
                  
                    <div class="header-menu-actions-action header-menu-actions-action--social mobile">
                      <a class="icon icon--lg icon--fill  header-icon header-icon-border-shape-none header-icon-border-style-outline"  href="https://www.instagram.com/yu.genglin/" target="_blank" aria-label="Instagram">
                        <svg viewBox="23 23 64 64">
                          <use xlink:href="#instagram-unauth-icon" width="110" height="110"></use>
                        </svg>
                      </a>
                    </div>
                  
                    <div class="header-menu-actions-action header-menu-actions-action--social mobile">
                      <a class="icon icon--lg icon--fill  header-icon header-icon-border-shape-none header-icon-border-style-outline"  href="http://twitter.com/squarespacehttps://www.linkedin.com/in/genglin-yu/?isSelfProfile=true" target="_blank" aria-label="LinkedIn">
                        <svg viewBox="23 23 64 64">
                          <use xlink:href="#linkedin-unauth-icon" width="110" height="110"></use>
                        </svg>
                      </a>
                    </div>
                  
                    <div class="header-menu-actions-action header-menu-actions-action--social mobile">
                      <a class="icon icon--lg icon--fill  header-icon header-icon-border-shape-none header-icon-border-style-outline"  href="https://www.facebook.com/profile.php?id=100009310393967" target="_blank" aria-label="Facebook">
                        <svg viewBox="23 23 64 64">
                          <use xlink:href="#facebook-unauth-icon" width="110" height="110"></use>
                        </svg>
                      </a>
                    </div>
                  
                
              </div>
            
            
            
          </div>
        </nav>
      </div>
    </div>
    
    <script>
      (function() {
        var header = document.getElementById('header');
        if (!header) {
          return;
        }
        function setHeaderHeightVar() {
          document.documentElement.style.setProperty(
            '--header-height',
            header.getBoundingClientRect().height + 'px'
          );
        }
        setHeaderHeightVar();
        var images = header.getElementsByTagName('img');
        for (var i = 0; i < images.length; i++) {
          if (!images[i].complete) {
            images[i].addEventListener('load', setHeaderHeightVar);
          }
        }
      })();
      //# sourceURL=reserveSpaceForHeader.js
    </script>
  </header>




      <main id="page" class="container" role="main">
        
          <div class="system-page">
            <p>We couldn't find the page you were looking for. This is either because:</p>
<ul>
  <li>There is an error in the URL entered into your web browser. Please check the URL and try again.</li>
  <li>The page you are looking for has been moved or deleted.</li>
</ul>
<p>
  You can return to our homepage by <a href="/">clicking here</a>, or you can try searching for the
  content you are seeking by <a href="/search">clicking here</a>.
</p>
          </div>
        
      </main>
      
        <footer class="sections" id="footer-sections" data-footer-sections>
  
  
  
  
  
  
    
    


  
  











<section
  data-test="page-section"
  
  data-section-theme="bright-inverse"
  class='page-section 
    
      full-bleed-section
      layout-engine-section
    
    background-width--full-bleed
    
      
        section-height--custom
      
    
    
      content-width--wide
    
    horizontal-alignment--center
    vertical-alignment--middle
    
      
    
    
    bright-inverse'
  
  data-section-id="6ad6eae8921fff141cc328a9"
  
  data-controller="SectionWrapperController"
  data-current-styles="{
                                &quot;imageOverlayOpacity&quot;: 0.15,
                                &quot;backgroundWidth&quot;: &quot;background-width--full-bleed&quot;,
                                &quot;sectionHeight&quot;: &quot;section-height--custom&quot;,
                                &quot;customSectionHeight&quot;: 0,
                                &quot;horizontalAlignment&quot;: &quot;horizontal-alignment--center&quot;,
                                &quot;verticalAlignment&quot;: &quot;vertical-alignment--middle&quot;,
                                &quot;contentWidth&quot;: &quot;content-width--wide&quot;,
                                &quot;customContentWidth&quot;: 50,
                                &quot;sectionTheme&quot;: &quot;bright-inverse&quot;,
                                &quot;sectionAnimation&quot;: &quot;none&quot;,
                                &quot;backgroundMode&quot;: &quot;image&quot;
                              }"
  data-current-context="{
                                &quot;video&quot;: {
                                  &quot;playbackSpeed&quot;: 0.5,
                                  &quot;filter&quot;: 1,
                                  &quot;filterStrength&quot;: 0,
                                  &quot;zoom&quot;: 0,
                                  &quot;videoSourceProvider&quot;: &quot;none&quot;
                                },
                                &quot;backgroundImageId&quot;: null,
                                &quot;backgroundMediaEffect&quot;: {
                                  &quot;type&quot;: &quot;none&quot;
                                },
                                &quot;divider&quot;: {
                                  &quot;enabled&quot;: false
                                },
                                &quot;typeName&quot;: null
                              }"
  data-animation="none"
  data-fluid-engine-section
   
  
  
  
  
  


  data-sqsp-section="fluid-engine"


>
  <div
    class="section-border"
    
  >
    <div class="section-background">
    
      
    
    </div>
  </div>
  <div
    class='content-wrapper'
    style='
      
        
          
          padding-top: calc(0vmax / 10); padding-bottom: calc(0vmax / 10);
        
      
    '
  >
    <div
      class="content"
      
    >
      
      
      
      
      
      
      
      
      
      
      <div data-fluid-engine="true"><style>

.fe-6ad6eae8921fff141cc328a8 {
  --grid-gutter: calc(var(--sqs-mobile-site-gutter, 6vw) - 11.0px);
  --cell-max-width: calc( ( var(--sqs-site-max-width, 1500px) - (11.0px * (8 - 1)) ) / 8 );

  display: grid;
  position: relative;
  grid-area: 1/1/-1/-1;
  grid-template-rows: repeat(24,minmax(24px, auto));
  grid-template-columns:
    minmax(var(--grid-gutter), 1fr)
    repeat(8, minmax(0, var(--cell-max-width)))
    minmax(var(--grid-gutter), 1fr);
  row-gap: 11.0px;
  column-gap: 11.0px;
  overflow-x: hidden;
  overflow-x: clip;
}

@media (min-width: 768px) {
  .background-width--inset .fe-6ad6eae8921fff141cc328a8 {
    --inset-padding: calc(var(--sqs-site-gutter) * 2);
  }

  .fe-6ad6eae8921fff141cc328a8 {
    --grid-gutter: calc(var(--sqs-site-gutter, 4vw) - 11.0px);
    --cell-max-width: calc( ( var(--sqs-site-max-width, 1500px) - (11.0px * (24 - 1)) ) / 24 );
    --inset-padding: 0vw;

    --row-height-scaling-factor: 0.0215;
    --container-width: min(var(--sqs-site-max-width, 1500px), calc(100vw - var(--sqs-site-gutter, 4vw) * 2 - var(--inset-padding) ));

    grid-template-rows: repeat(20,minmax(calc(var(--container-width) * var(--row-height-scaling-factor)), auto));
    grid-template-columns:
      minmax(var(--grid-gutter), 1fr)
      repeat(24, minmax(0, var(--cell-max-width)))
      minmax(var(--grid-gutter), 1fr);
  }
}


  .fe-block-379e6c842914678e7ece {
    grid-area: 2/2/6/10;
    z-index: 6;

    @media (max-width: 767px) {
      
        
      
      
    }
  }

  .fe-block-379e6c842914678e7ece .sqs-block {
    justify-content: center;
  }

  .fe-block-379e6c842914678e7ece .sqs-block-alignment-wrapper {
    align-items: center;
  }

  @media (min-width: 768px) {
    .fe-block-379e6c842914678e7ece {
      grid-area: 2/2/5/23;
      z-index: 5;

      
        
      

      
    }

    .fe-block-379e6c842914678e7ece .sqs-block {
      justify-content: center;
    }

    .fe-block-379e6c842914678e7ece .sqs-block-alignment-wrapper {
      align-items: center;
    }
  }

  .fe-block-adae6272fc7d07e1df58 {
    grid-area: 7/2/14/10;
    z-index: 1;

    @media (max-width: 767px) {
      
        
      
      
    }
  }

  .fe-block-adae6272fc7d07e1df58 .sqs-block {
    justify-content: center;
  }

  .fe-block-adae6272fc7d07e1df58 .sqs-block-alignment-wrapper {
    align-items: center;
  }

  @media (min-width: 768px) {
    .fe-block-adae6272fc7d07e1df58 {
      grid-area: 7/2/20/9;
      z-index: 1;

      
        
      

      
    }

    .fe-block-adae6272fc7d07e1df58 .sqs-block {
      justify-content: center;
    }

    .fe-block-adae6272fc7d07e1df58 .sqs-block-alignment-wrapper {
      align-items: center;
    }
  }

  .fe-block-097adbfd6b176479e6e1 {
    grid-area: 8/2/10/6;
    z-index: 4;

    @media (max-width: 767px) {
      
        
      
      
    }
  }

  .fe-block-097adbfd6b176479e6e1 .sqs-block {
    justify-content: flex-start;
  }

  .fe-block-097adbfd6b176479e6e1 .sqs-block-alignment-wrapper {
    align-items: flex-start;
  }

  @media (min-width: 768px) {
    .fe-block-097adbfd6b176479e6e1 {
      grid-area: 7/2/9/9;
      z-index: 4;

      
        
      

      
    }

    .fe-block-097adbfd6b176479e6e1 .sqs-block {
      justify-content: center;
    }

    .fe-block-097adbfd6b176479e6e1 .sqs-block-alignment-wrapper {
      align-items: center;
    }
  }

  .fe-block-bbc16560ba1a386dba8e {
    grid-area: 10/2/13/10;
    z-index: 2;

    @media (max-width: 767px) {
      
      
    }
  }

  .fe-block-bbc16560ba1a386dba8e .sqs-block {
    justify-content: flex-start;
  }

  .fe-block-bbc16560ba1a386dba8e .sqs-block-alignment-wrapper {
    align-items: flex-start;
  }

  @media (min-width: 768px) {
    .fe-block-bbc16560ba1a386dba8e {
      grid-area: 9/2/12/9;
      z-index: 2;

      

      
    }

    .fe-block-bbc16560ba1a386dba8e .sqs-block {
      justify-content: flex-start;
    }

    .fe-block-bbc16560ba1a386dba8e .sqs-block-alignment-wrapper {
      align-items: flex-start;
    }
  }

  .fe-block-edadef04b80c17e7da08 {
    grid-area: 15/2/17/6;
    z-index: 5;

    @media (max-width: 767px) {
      
        
      
      
    }
  }

  .fe-block-edadef04b80c17e7da08 .sqs-block {
    justify-content: flex-start;
  }

  .fe-block-edadef04b80c17e7da08 .sqs-block-alignment-wrapper {
    align-items: flex-start;
  }

  @media (min-width: 768px) {
    .fe-block-edadef04b80c17e7da08 {
      grid-area: 7/14/9/17;
      z-index: 6;

      
        
      

      
    }

    .fe-block-edadef04b80c17e7da08 .sqs-block {
      justify-content: center;
    }

    .fe-block-edadef04b80c17e7da08 .sqs-block-alignment-wrapper {
      align-items: center;
    }
  }

  .fe-block-ceb583628fff2388f775 {
    grid-area: 17/2/22/6;
    z-index: 3;

    @media (max-width: 767px) {
      
      
    }
  }

  .fe-block-ceb583628fff2388f775 .sqs-block {
    justify-content: flex-start;
  }

  .fe-block-ceb583628fff2388f775 .sqs-block-alignment-wrapper {
    align-items: flex-start;
  }

  @media (min-width: 768px) {
    .fe-block-ceb583628fff2388f775 {
      grid-area: 9/14/13/20;
      z-index: 3;

      

      
    }

    .fe-block-ceb583628fff2388f775 .sqs-block {
      justify-content: flex-start;
    }

    .fe-block-ceb583628fff2388f775 .sqs-block-alignment-wrapper {
      align-items: flex-start;
    }
  }

  .fe-block-yui_3_17_2_1_1792481559676_3551 {
    grid-area: 23/1/24/10;
    z-index: 7;

    @media (max-width: 767px) {
      
        
      
      
    }
  }

  .fe-block-yui_3_17_2_1_1792481559676_3551 .sqs-block {
    justify-content: center;
  }

  .fe-block-yui_3_17_2_1_1792481559676_3551 .sqs-block-alignment-wrapper {
    align-items: center;
  }

  @media (min-width: 768px) {
    .fe-block-yui_3_17_2_1_1792481559676_3551 {
      grid-area: 4/14/7/20;
      z-index: 8;

      
        
      

      
    }

    .fe-block-yui_3_17_2_1_1792481559676_3551 .sqs-block {
      justify-content: center;
    }

    .fe-block-yui_3_17_2_1_1792481559676_3551 .sqs-block-alignment-wrapper {
      align-items: center;
    }
  }

</style><div class="fluid-engine fe-6ad6eae8921fff141cc328a8"><div class="fe-block fe-block-379e6c842914678e7ece"><div class="sqs-block website-component-block sqs-block-website-component sqs-block-html html-block" data-block-css="[&quot;https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.html/e4d8cee0-b2a8-4d2c-acaf-62c051981b6d_997/website.components.html.styles.css&quot;]" data-block-scripts="[&quot;https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.html/e4d8cee0-b2a8-4d2c-acaf-62c051981b6d_997/website.components.html.visitor.js&quot;]" data-block-type="1337" data-definition-name="website.components.html" data-sqsp-block="text" data-website-component-id="379e6c842914678e7ece" id="block-379e6c842914678e7ece"><div class="sqs-block-content"><div class="sqs-text-block-container">
  
  <div class="sqs-html-content" data-sqsp-text-block-content><h1 style="white-space:pre-wrap;" data-rte-preserve-empty="true">Connect With Me</h1></div>


  
<style id="container-styles">#block-379e6c842914678e7ece {
    
    --stroke-style: none;--stroke-thickness: 6px;
    
      
      
      
    



  }

  #block-379e6c842914678e7ece .sqs-html-content {
    
    --tweak-text-block-padding: 6% 6% 6% 6%;
  --tweak-text-block-padding: initial;
}

  .fe-block-379e6c842914678e7ece {
      mix-blend-mode: var(--tweak-text-block-blend
  );
      border-radius: var(--tweak-text-block-radius);
  }

  
  
.fe-block-379e6c842914678e7ece {
      --tweak-text-block-radius: 0px 0px 0px 0px;
    }


  
  .fe-block-379e6c842914678e7ece {
      --tweak-text-block-blend
  : normal;
    }
  

  .fe-block-379e6c842914678e7ece {
    --blur-value: blur(15px);}

</style>

<style id="override-container-styles">
    @media screen and (max-width: 767px) {
          
            

#block-379e6c842914678e7ece {
            
            }
        }
    
  
    @media screen and (max-width: 767px) {
          #block-379e6c842914678e7ece .sqs-html-content {
            
            }
        }
    
  @media screen and (max-width: 767px) {
          
          

          
          
          
        }</style>
<style class="transform-overrides-vars">
  
</style>




</div>
</div></div></div><div class="fe-block fe-block-adae6272fc7d07e1df58"><div class="sqs-block website-component-block sqs-block-website-component" data-block-css="[&quot;https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.shape/48f8fea7-7663-4155-8a4f-74e7d943f820_1392/website.components.shape.styles.css&quot;]" data-block-scripts="[&quot;https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.shape/48f8fea7-7663-4155-8a4f-74e7d943f820_1392/website.components.shape.visitor.js&quot;]" data-block-type="1337" data-definition-name="website.components.shape" data-sqsp-block="shape" data-website-component-id="adae6272fc7d07e1df58" id="block-adae6272fc7d07e1df58"><div class="sqs-block-content">
























<div
  class="sqs-shape-block-outer-container"
  
>

  
  
    
      
        
  
  	<div
      class="sqs-shape-block-container sqs-block-alignment-wrapper 
  sqs-shape-block-container-system_desktop
 hidden-stretch-block"
      data-stretched-to-fill
      data-shape-name="rectangle"
      data-breakpoint-override-id="
system_desktop
"
      data-desktop-drop-shadow={"angle":145,"blur":{"unit":"px","value":3},"color":{"type":"THEME_COLOR"},"distance":{"unit":"px","value":2}}
      data-desktop-blur={"blurRadius":{"unit":"px","value":15},"enabled":false,"filterType":"element"}
      
      
        data-blend-mode='normal'
      
      
      
  
    
    
    
    
    
    
  

    >
  		
  
    
    
    
    
    
    <svg xmlns="http://www.w3.org/2000/svg" data-sqsp-shape-block-shape class="sqs-shape sqs-shape-rectangle" style="background-color: unset">
      
      <rect style="width: calc(100% + var(--shape-block-stroke-width, 0px)); height: calc(100% + var(--shape-block-stroke-width, 0px));" x="calc(var(--shape-block-stroke-width, 0px) / -2)" y="calc(var(--shape-block-stroke-width, 0px) / -2)"/>
      
    </svg>
  

    </div>
  

    
      
        
  
  	
  

    
  



  <style>
    #block-adae6272fc7d07e1df58 .sqs-shape-block-container-system_desktop {
      display: flex;
    }
    #block-adae6272fc7d07e1df58 .sqs-block-alignment-wrapper {
      
      
      justify-content: center;
      
      
    }

    
      #block-adae6272fc7d07e1df58 .sqs-shape > * {
        
          stroke: none;
        
      }
    

    
      
    

    
      
      
    

    
      
      
    
  </style>
  <style class="overrides-vars">
    
  	#block-adae6272fc7d07e1df58 .sqs-shape-block-container-system_desktop {
    	display: flex;
    }
  @media screen and (max-width: 767px) {
      


      #block-adae6272fc7d07e1df58 .sqs-block-alignment-wrapper {
        
        
          justify-content: center;
        
        
      }

      

      #block-adae6272fc7d07e1df58 {
        
          
        

        
          
          
        

        
          
          
        
      }
    }
  
  </style>
  <style class="transform-vars">
    .fe-block-adae6272fc7d07e1df58 {
      --opacity: 100%;
      --translate-x: 0px;
      --translate-y: 0px;
      --rotation: 0deg;
      --scale-x: 100%;
      --scale-y: 100%;
      --skew-x: 0deg;
      --skew-y: 0deg;
      --origin-x: 50%;
      --origin-y: 50%;
      --block-transform: none;

      opacity: var(--opacity, 1);
      transform: var(--block-transform);
      transform-origin: var(--origin-x) var(--origin-y);
    }
  </style><style class="transform-overrides-vars">
  
</style>

  



</div>
</div></div></div><div class="fe-block fe-block-097adbfd6b176479e6e1"><div class="sqs-block website-component-block sqs-block-website-component sqs-block-html html-block" data-block-css="[&quot;https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.html/e4d8cee0-b2a8-4d2c-acaf-62c051981b6d_997/website.components.html.styles.css&quot;]" data-block-scripts="[&quot;https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.html/e4d8cee0-b2a8-4d2c-acaf-62c051981b6d_997/website.components.html.visitor.js&quot;]" data-block-type="1337" data-definition-name="website.components.html" data-sqsp-block="text" data-website-component-id="097adbfd6b176479e6e1" id="block-097adbfd6b176479e6e1"><div class="sqs-block-content"><div class="sqs-text-block-container">
  
  <div class="sqs-html-content" data-sqsp-text-block-content><h3 data-indent="1" style="margin-left: 40px; white-space: pre-wrap" data-rte-preserve-empty="true"><span class="sqsrte-text-color--white">Contact</span></h3></div>


  
<style id="container-styles">#block-097adbfd6b176479e6e1 {
    
    --stroke-style: none;--stroke-thickness: 6px;
    
      
      
      
    



  }

  #block-097adbfd6b176479e6e1 .sqs-html-content {
    
    --tweak-text-block-padding: 6% 6% 6% 6%;
  --tweak-text-block-padding: initial;
}

  .fe-block-097adbfd6b176479e6e1 {
      mix-blend-mode: var(--tweak-text-block-blend
  );
      border-radius: var(--tweak-text-block-radius);
  }

  
  
.fe-block-097adbfd6b176479e6e1 {
      --tweak-text-block-radius: 0px 0px 0px 0px;
    }


  
  .fe-block-097adbfd6b176479e6e1 {
      --tweak-text-block-blend
  : normal;
    }
  

  .fe-block-097adbfd6b176479e6e1 {
    --blur-value: blur(15px);}

</style>

<style id="override-container-styles">
    @media screen and (max-width: 767px) {
          
            

#block-097adbfd6b176479e6e1 {
            
            }
        }
    
  
    @media screen and (max-width: 767px) {
          #block-097adbfd6b176479e6e1 .sqs-html-content {
            
            }
        }
    
  @media screen and (max-width: 767px) {
          
          

          
          
          
        }</style>
<style class="transform-overrides-vars">
  
</style>




</div>
</div></div></div><div class="fe-block fe-block-bbc16560ba1a386dba8e"><div class="sqs-block website-component-block sqs-block-website-component sqs-block-html html-block" data-block-css="[&quot;https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.html/e4d8cee0-b2a8-4d2c-acaf-62c051981b6d_997/website.components.html.styles.css&quot;]" data-block-scripts="[&quot;https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.html/e4d8cee0-b2a8-4d2c-acaf-62c051981b6d_997/website.components.html.visitor.js&quot;]" data-block-type="1337" data-definition-name="website.components.html" data-sqsp-block="text" data-website-component-id="bbc16560ba1a386dba8e" id="block-bbc16560ba1a386dba8e"><div class="sqs-block-content"><div class="sqs-text-block-container">
  
  <div class="sqs-html-content" data-sqsp-text-block-content><p data-indent="1" style="margin-left: 40px; white-space: pre-wrap" class="sqsrte-large" data-rte-preserve-empty="true"><span class="sqsrte-text-color--white">gly310@gmail.com</span></p><p data-indent="1" style="margin-left: 40px; white-space: pre-wrap" class="sqsrte-large" data-rte-preserve-empty="true"><span class="sqsrte-text-color--white">gyu@student.otis.edu</span></p></div>


  
<style id="container-styles">#block-bbc16560ba1a386dba8e {
    
    --stroke-style: none;--stroke-thickness: 6px;
    
      
      
      
    



  }

  #block-bbc16560ba1a386dba8e .sqs-html-content {
    
    --tweak-text-block-padding: 6% 6% 6% 6%;
  --tweak-text-block-padding: initial;
}

  .fe-block-bbc16560ba1a386dba8e {
      mix-blend-mode: var(--tweak-text-block-blend
  );
      border-radius: var(--tweak-text-block-radius);
  }

  
  
.fe-block-bbc16560ba1a386dba8e {
      --tweak-text-block-radius: 0px 0px 0px 0px;
    }


  
  .fe-block-bbc16560ba1a386dba8e {
      --tweak-text-block-blend
  : normal;
    }
  

  .fe-block-bbc16560ba1a386dba8e {
    --blur-value: blur(15px);}

</style>

<style id="override-container-styles">
    @media screen and (max-width: 767px) {
          
            

#block-bbc16560ba1a386dba8e {
            
            }
        }
    
  
    @media screen and (max-width: 767px) {
          #block-bbc16560ba1a386dba8e .sqs-html-content {
            
            }
        }
    
  @media screen and (max-width: 767px) {
          
          

          
          
          
        }</style>
<style class="transform-overrides-vars">
  
</style>




</div>
</div></div></div><div class="fe-block fe-block-edadef04b80c17e7da08"><div class="sqs-block website-component-block sqs-block-website-component sqs-block-html html-block" data-block-css="[&quot;https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.html/e4d8cee0-b2a8-4d2c-acaf-62c051981b6d_997/website.components.html.styles.css&quot;]" data-block-scripts="[&quot;https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.html/e4d8cee0-b2a8-4d2c-acaf-62c051981b6d_997/website.components.html.visitor.js&quot;]" data-block-type="1337" data-definition-name="website.components.html" data-sqsp-block="text" data-website-component-id="edadef04b80c17e7da08" id="block-edadef04b80c17e7da08"><div class="sqs-block-content"><div class="sqs-text-block-container">
  
  <div class="sqs-html-content" data-sqsp-text-block-content><h3 data-indent="1" style="margin-left: 40px; white-space: pre-wrap" data-rte-preserve-empty="true">Follow</h3></div>


  
<style id="container-styles">#block-edadef04b80c17e7da08 {
    
    --stroke-style: none;--stroke-thickness: 6px;
    
      
      
      
    



  }

  #block-edadef04b80c17e7da08 .sqs-html-content {
    
    --tweak-text-block-padding: 6% 6% 6% 6%;
  --tweak-text-block-padding: initial;
}

  .fe-block-edadef04b80c17e7da08 {
      mix-blend-mode: var(--tweak-text-block-blend
  );
      border-radius: var(--tweak-text-block-radius);
  }

  
  
.fe-block-edadef04b80c17e7da08 {
      --tweak-text-block-radius: 0px 0px 0px 0px;
    }


  
  .fe-block-edadef04b80c17e7da08 {
      --tweak-text-block-blend
  : normal;
    }
  

  .fe-block-edadef04b80c17e7da08 {
    --blur-value: blur(15px);}

</style>

<style id="override-container-styles">
    @media screen and (max-width: 767px) {
          
            

#block-edadef04b80c17e7da08 {
            
            }
        }
    
  
    @media screen and (max-width: 767px) {
          #block-edadef04b80c17e7da08 .sqs-html-content {
            
            }
        }
    
  @media screen and (max-width: 767px) {
          
          

          
          
          
        }</style>
<style class="transform-overrides-vars">
  
</style>




</div>
</div></div></div><div class="fe-block fe-block-ceb583628fff2388f775"><div class="sqs-block website-component-block sqs-block-website-component sqs-block-html html-block" data-block-css="[&quot;https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.html/e4d8cee0-b2a8-4d2c-acaf-62c051981b6d_997/website.components.html.styles.css&quot;]" data-block-scripts="[&quot;https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.html/e4d8cee0-b2a8-4d2c-acaf-62c051981b6d_997/website.components.html.visitor.js&quot;]" data-block-type="1337" data-definition-name="website.components.html" data-sqsp-block="text" data-website-component-id="ceb583628fff2388f775" id="block-ceb583628fff2388f775"><div class="sqs-block-content"><div class="sqs-text-block-container">
  
  <div class="sqs-html-content" data-sqsp-text-block-content><p data-indent="1" style="margin-left: 40px; white-space: pre-wrap" class="sqsrte-large" data-rte-preserve-empty="true">Instagram: <a target="_blank" href="https://www.instagram.com/yu.genglin/">@yu.genglin</a></p><p data-indent="1" style="margin-left: 40px; white-space: pre-wrap" class="sqsrte-large" data-rte-preserve-empty="true">Linkedin: <a target="_blank" href="https://www.linkedin.com/in/genglin-yu/?isSelfProfile=true">Genglin Yu </a></p></div>


  
<style id="container-styles">#block-ceb583628fff2388f775 {
    
    --stroke-style: none;--stroke-thickness: 6px;
    
      
      
      
    



  }

  #block-ceb583628fff2388f775 .sqs-html-content {
    
    --tweak-text-block-padding: 6% 6% 6% 6%;
  --tweak-text-block-padding: initial;
}

  .fe-block-ceb583628fff2388f775 {
      mix-blend-mode: var(--tweak-text-block-blend
  );
      border-radius: var(--tweak-text-block-radius);
  }

  
  
.fe-block-ceb583628fff2388f775 {
      --tweak-text-block-radius: 0px 0px 0px 0px;
    }


  
  .fe-block-ceb583628fff2388f775 {
      --tweak-text-block-blend
  : normal;
    }
  

  .fe-block-ceb583628fff2388f775 {
    --blur-value: blur(15px);}

</style>

<style id="override-container-styles">
    @media screen and (max-width: 767px) {
          
            

#block-ceb583628fff2388f775 {
            
            }
        }
    
  
    @media screen and (max-width: 767px) {
          #block-ceb583628fff2388f775 .sqs-html-content {
            
            }
        }
    
  @media screen and (max-width: 767px) {
          
          

          
          
          
        }</style>
<style class="transform-overrides-vars">
  
</style>




</div>
</div></div></div><div class="fe-block fe-block-yui_3_17_2_1_1792481559676_3551"><div class="sqs-block website-component-block sqs-block-website-component" data-block-css="[&quot;https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.shape/48f8fea7-7663-4155-8a4f-74e7d943f820_1392/website.components.shape.styles.css&quot;]" data-block-scripts="[&quot;https://definitions.sqspcdn.com/website-component-definition/static-assets/website.components.shape/48f8fea7-7663-4155-8a4f-74e7d943f820_1392/website.components.shape.visitor.js&quot;]" data-block-type="1337" data-definition-name="website.components.shape" data-sqsp-block="shape" data-website-component-id="yui_3_17_2_1_1792481559676_3551" id="block-yui_3_17_2_1_1792481559676_3551"><div class="sqs-block-content">
























<div
  class="sqs-shape-block-outer-container"
  
>

  
  
    
      
        
  
  	<div
      class="sqs-shape-block-container sqs-block-alignment-wrapper 
  sqs-shape-block-container-system_desktop
 hidden-stretch-block"
      data-stretched-to-fill
      data-shape-name="rectangle"
      data-breakpoint-override-id="
system_desktop
"
      data-desktop-drop-shadow={"angle":145,"blur":{"unit":"px","value":3},"color":{"type":"THEME_COLOR"},"distance":{"unit":"px","value":2}}
      data-desktop-blur={"blurRadius":{"unit":"px","value":15},"enabled":false,"filterType":"element"}
      
      
        data-blend-mode='normal'
      
      
      
  
    
    
    
    
    
    
  

    >
  		
  
    
    
    
    
    
    <svg xmlns="http://www.w3.org/2000/svg" data-sqsp-shape-block-shape class="sqs-shape sqs-shape-rectangle" style="background-color: unset">
      
      <rect style="width: calc(100% + var(--shape-block-stroke-width, 0px)); height: calc(100% + var(--shape-block-stroke-width, 0px));" x="calc(var(--shape-block-stroke-width, 0px) / -2)" y="calc(var(--shape-block-stroke-width, 0px) / -2)"/>
      
    </svg>
  

    </div>
  

    
      
        
  
  	
  

    
  



  <style>
    #block-yui_3_17_2_1_1792481559676_3551 .sqs-shape-block-container-system_desktop {
      display: flex;
    }
    #block-yui_3_17_2_1_1792481559676_3551 .sqs-block-alignment-wrapper {
      
      
      justify-content: center;
      
      
    }

    
      #block-yui_3_17_2_1_1792481559676_3551 .sqs-shape > * {
        
          stroke: none;
        
      }
    

    
      
    

    
      
      
    

    
      
      
    
  </style>
  <style class="overrides-vars">
    
  	#block-yui_3_17_2_1_1792481559676_3551 .sqs-shape-block-container-system_desktop {
    	display: flex;
    }
  @media screen and (max-width: 767px) {
      


      #block-yui_3_17_2_1_1792481559676_3551 .sqs-block-alignment-wrapper {
        
        
          justify-content: center;
        
        
      }

      

      #block-yui_3_17_2_1_1792481559676_3551 {
        
          
        

        
          
          
        

        
          
          
        
      }
    }
  
  </style>
  <style class="transform-vars">
    .fe-block-yui_3_17_2_1_1792481559676_3551 {
      --opacity: 100%;
      --translate-x: 0px;
      --translate-y: 0px;
      --rotation: 0deg;
      --scale-x: 100%;
      --scale-y: 100%;
      --skew-x: 0deg;
      --skew-y: 0deg;
      --origin-x: 50%;
      --origin-y: 50%;
      --block-transform: none;

      opacity: var(--opacity, 1);
      transform: var(--block-transform);
      transform-origin: var(--origin-x) var(--origin-y);
    }
  </style><style class="transform-overrides-vars">
  
</style>

  



</div>
</div></div></div></div></div>
    </div>
  
  </div>
  
</section>

  
</footer>

      
    </div>

    <script defer="true" src="https://static1.squarespace.com/static/vta/5c5a519771c10ba3470d8101/scripts/site-bundle.17bbc1daaa96c6be161d933b8de8a091.js" type="text/javascript"></script>
    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" style="display:none" data-usage="social-icons-svg"><symbol id="instagram-unauth-icon" viewBox="0 0 64 64"><path d="M46.91,25.816c-0.073-1.597-0.326-2.687-0.697-3.641c-0.383-0.986-0.896-1.823-1.73-2.657c-0.834-0.834-1.67-1.347-2.657-1.73c-0.954-0.371-2.045-0.624-3.641-0.697C36.585,17.017,36.074,17,32,17s-4.585,0.017-6.184,0.09c-1.597,0.073-2.687,0.326-3.641,0.697c-0.986,0.383-1.823,0.896-2.657,1.73c-0.834,0.834-1.347,1.67-1.73,2.657c-0.371,0.954-0.624,2.045-0.697,3.641C17.017,27.415,17,27.926,17,32c0,4.074,0.017,4.585,0.09,6.184c0.073,1.597,0.326,2.687,0.697,3.641c0.383,0.986,0.896,1.823,1.73,2.657c0.834,0.834,1.67,1.347,2.657,1.73c0.954,0.371,2.045,0.624,3.641,0.697C27.415,46.983,27.926,47,32,47s4.585-0.017,6.184-0.09c1.597-0.073,2.687-0.326,3.641-0.697c0.986-0.383,1.823-0.896,2.657-1.73c0.834-0.834,1.347-1.67,1.73-2.657c0.371-0.954,0.624-2.045,0.697-3.641C46.983,36.585,47,36.074,47,32S46.983,27.415,46.91,25.816z M44.21,38.061c-0.067,1.462-0.311,2.257-0.516,2.785c-0.272,0.7-0.597,1.2-1.122,1.725c-0.525,0.525-1.025,0.85-1.725,1.122c-0.529,0.205-1.323,0.45-2.785,0.516c-1.581,0.072-2.056,0.087-6.061,0.087s-4.48-0.015-6.061-0.087c-1.462-0.067-2.257-0.311-2.785-0.516c-0.7-0.272-1.2-0.597-1.725-1.122c-0.525-0.525-0.85-1.025-1.122-1.725c-0.205-0.529-0.45-1.323-0.516-2.785c-0.072-1.582-0.087-2.056-0.087-6.061s0.015-4.48,0.087-6.061c0.067-1.462,0.311-2.257,0.516-2.785c0.272-0.7,0.597-1.2,1.122-1.725c0.525-0.525,1.025-0.85,1.725-1.122c0.529-0.205,1.323-0.45,2.785-0.516c1.582-0.072,2.056-0.087,6.061-0.087s4.48,0.015,6.061,0.087c1.462,0.067,2.257,0.311,2.785,0.516c0.7,0.272,1.2,0.597,1.725,1.122c0.525,0.525,0.85,1.025,1.122,1.725c0.205,0.529,0.45,1.323,0.516,2.785c0.072,1.582,0.087,2.056,0.087,6.061S44.282,36.48,44.21,38.061z M32,24.297c-4.254,0-7.703,3.449-7.703,7.703c0,4.254,3.449,7.703,7.703,7.703c4.254,0,7.703-3.449,7.703-7.703C39.703,27.746,36.254,24.297,32,24.297z M32,37c-2.761,0-5-2.239-5-5c0-2.761,2.239-5,5-5s5,2.239,5,5C37,34.761,34.761,37,32,37z M40.007,22.193c-0.994,0-1.8,0.806-1.8,1.8c0,0.994,0.806,1.8,1.8,1.8c0.994,0,1.8-0.806,1.8-1.8C41.807,22.999,41.001,22.193,40.007,22.193z"/></symbol><symbol id="instagram-unauth-mask" viewBox="0 0 64 64"><path d="M43.693,23.153c-0.272-0.7-0.597-1.2-1.122-1.725c-0.525-0.525-1.025-0.85-1.725-1.122c-0.529-0.205-1.323-0.45-2.785-0.517c-1.582-0.072-2.056-0.087-6.061-0.087s-4.48,0.015-6.061,0.087c-1.462,0.067-2.257,0.311-2.785,0.517c-0.7,0.272-1.2,0.597-1.725,1.122c-0.525,0.525-0.85,1.025-1.122,1.725c-0.205,0.529-0.45,1.323-0.516,2.785c-0.072,1.582-0.087,2.056-0.087,6.061s0.015,4.48,0.087,6.061c0.067,1.462,0.311,2.257,0.516,2.785c0.272,0.7,0.597,1.2,1.122,1.725s1.025,0.85,1.725,1.122c0.529,0.205,1.323,0.45,2.785,0.516c1.581,0.072,2.056,0.087,6.061,0.087s4.48-0.015,6.061-0.087c1.462-0.067,2.257-0.311,2.785-0.516c0.7-0.272,1.2-0.597,1.725-1.122s0.85-1.025,1.122-1.725c0.205-0.529,0.45-1.323,0.516-2.785c0.072-1.582,0.087-2.056,0.087-6.061s-0.015-4.48-0.087-6.061C44.143,24.476,43.899,23.682,43.693,23.153z M32,39.703c-4.254,0-7.703-3.449-7.703-7.703s3.449-7.703,7.703-7.703s7.703,3.449,7.703,7.703S36.254,39.703,32,39.703z M40.007,25.793c-0.994,0-1.8-0.806-1.8-1.8c0-0.994,0.806-1.8,1.8-1.8c0.994,0,1.8,0.806,1.8,1.8C41.807,24.987,41.001,25.793,40.007,25.793z M0,0v64h64V0H0z M46.91,38.184c-0.073,1.597-0.326,2.687-0.697,3.641c-0.383,0.986-0.896,1.823-1.73,2.657c-0.834,0.834-1.67,1.347-2.657,1.73c-0.954,0.371-2.044,0.624-3.641,0.697C36.585,46.983,36.074,47,32,47s-4.585-0.017-6.184-0.09c-1.597-0.073-2.687-0.326-3.641-0.697c-0.986-0.383-1.823-0.896-2.657-1.73c-0.834-0.834-1.347-1.67-1.73-2.657c-0.371-0.954-0.624-2.044-0.697-3.641C17.017,36.585,17,36.074,17,32c0-4.074,0.017-4.585,0.09-6.185c0.073-1.597,0.326-2.687,0.697-3.641c0.383-0.986,0.896-1.823,1.73-2.657c0.834-0.834,1.67-1.347,2.657-1.73c0.954-0.371,2.045-0.624,3.641-0.697C27.415,17.017,27.926,17,32,17s4.585,0.017,6.184,0.09c1.597,0.073,2.687,0.326,3.641,0.697c0.986,0.383,1.823,0.896,2.657,1.73c0.834,0.834,1.347,1.67,1.73,2.657c0.371,0.954,0.624,2.044,0.697,3.641C46.983,27.415,47,27.926,47,32C47,36.074,46.983,36.585,46.91,38.184z M32,27c-2.761,0-5,2.239-5,5s2.239,5,5,5s5-2.239,5-5S34.761,27,32,27z"/></symbol><symbol id="linkedin-unauth-icon" viewBox="0 0 64 64"><path d="M20.4,44h5.4V26.6h-5.4V44z M23.1,18c-1.7,0-3.1,1.4-3.1,3.1c0,1.7,1.4,3.1,3.1,3.1 c1.7,0,3.1-1.4,3.1-3.1C26.2,19.4,24.8,18,23.1,18z M39.5,26.2c-2.6,0-4.4,1.4-5.1,2.8h-0.1v-2.4h-5.2V44h5.4v-8.6 c0-2.3,0.4-4.5,3.2-4.5c2.8,0,2.8,2.6,2.8,4.6V44H46v-9.5C46,29.8,45,26.2,39.5,26.2z"/></symbol><symbol id="linkedin-unauth-mask" viewBox="0 0 64 64"><path d="M0,0v64h64V0H0z M25.8,44h-5.4V26.6h5.4V44z M23.1,24.3c-1.7,0-3.1-1.4-3.1-3.1c0-1.7,1.4-3.1,3.1-3.1 c1.7,0,3.1,1.4,3.1,3.1C26.2,22.9,24.8,24.3,23.1,24.3z M46,44h-5.4v-8.4c0-2,0-4.6-2.8-4.6c-2.8,0-3.2,2.2-3.2,4.5V44h-5.4V26.6 h5.2V29h0.1c0.7-1.4,2.5-2.8,5.1-2.8c5.5,0,6.5,3.6,6.5,8.3V44z"/></symbol><symbol id="facebook-unauth-icon" viewBox="0 0 64 64"><path d="M34.1,47V33.3h4.6l0.7-5.3h-5.3v-3.4c0-1.5,0.4-2.6,2.6-2.6l2.8,0v-4.8c-0.5-0.1-2.2-0.2-4.1-0.2 c-4.1,0-6.9,2.5-6.9,7V28H24v5.3h4.6V47H34.1z"/></symbol><symbol id="facebook-unauth-mask" viewBox="0 0 64 64"><path d="M0,0v64h64V0H0z M39.6,22l-2.8,0c-2.2,0-2.6,1.1-2.6,2.6V28h5.3l-0.7,5.3h-4.6V47h-5.5V33.3H24V28h4.6V24 c0-4.6,2.8-7,6.9-7c2,0,3.6,0.1,4.1,0.2V22z"/></symbol></svg>

  </body>
</html>
